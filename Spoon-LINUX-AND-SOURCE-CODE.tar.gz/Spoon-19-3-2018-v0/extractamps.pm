use user_config;
use strict;
use extractamps;
	
sub extractinsamp
{
    my ($config)=@_;
    my %config=%{$config}; 
    my $outfile=$config{"OUTDIR"}.$config{PLATDIR}."In_silico_amplimers_sequence.fasta"; 
    my $dir = $config{FASTADIR};
    my %ampsinfo=read_amps_infos(\%config);
    my @fafiles = user_config::get_fasta_in_dir($dir,\%config);        
    foreach my $file(@fafiles)
    {
           #take every fasta file and fitch seq(s) in it 
           my %seq = user_config::get_seq_in_fasta_file($dir.$config{PLATDIR}.$file);
           foreach my $acc(keys(%seq))
           {
             #If this file contains seq has hits 
             if($ampsinfo{$acc})
                {
                  getampsseq($acc,$seq{$acc},$ampsinfo{$acc},\%config,$outfile);
                }                         
           } 
    } 

}

sub getampsseq
{
	my ($acc,$seq,$ampsinfo,$config,$outseqf)=@_;
	my %config=%{$config};
	my @ampsinfo=@{$ampsinfo};
        my $seqlen=length($seq);
        #As we don't want tp repeat sequences in the file awe read the file if exists and get already exists sequences 
        my %pseq=read_prevoius_extraction($outseqf);
        open(OSFILE,">>".$outseqf); 
        foreach my $info(@ampsinfo)
	{
           my $start = $info->[0];
           my $end   = $info->[1];
           if($start-$config{"UPSTEAREM"}>=0)
             {$start -=$config{"UPSTEAREM"}}
           if($end+$config{"DOWNSTREAM"}<=$seqlen)
             {$end+=$config{"DOWNSTREAM"}}
           my $ampinfo = $info->[2]."-".$acc."-".$start."-".$end;
           my $subseq=substr($seq,$start,($end-$start));
            if(!$pseq{$ampinfo})
            {
             print OSFILE ">".$ampinfo."\n".$subseq."\n"; 
	    }
        }
        close OSFILE;
}
sub read_prevoius_extraction
{
 my ($outseqf)=@_;
 open(POSFILE,$outseqf);
 my %pseq;
 while(<POSFILE>)
 {
 chomp();
 if(/>(\S+)/)
  {
   $pseq{$1}=1;
  }
 }
 close POSFILE;
 return %pseq;
}
sub read_amps_infos
{
    my($config)=@_;
    my %config=%{$config};
    my $outfile=$config{"OUTDIR"}.$config{PLATDIR}."In_silico_PCR_Results.csv";
    my %ampsinfos;
    open(INSFILE,$outfile);
    while(<INSFILE>)
    {
     chomp();

      my @line=split(/\,/,$_);
      my $acc = $line[6];
      my $amps= $line[7];
      my $ampe= $line[8];
      my $primn=$line[0];
      #get rev primer length to get length of amp correctly for extarction
    
      push(@{$ampsinfos{$acc}},[$amps,$ampe,$primn]); 
    }
    close  INSFILE; 
    return %ampsinfos;     
}

1;
