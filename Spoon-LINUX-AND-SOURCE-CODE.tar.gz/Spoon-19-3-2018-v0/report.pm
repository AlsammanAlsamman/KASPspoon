package report;
use MainSpoon;
use strict;

#read insilico result file and return more then one values
 sub readins {
        my ($insfile,$ft,$allinsbands) = @_;
        my %ft=%{$ft};                     
        open( INFILE, "<$insfile" );
        while (<INFILE>) {
            if ( !(/Primer Name/) ) {
                chomp();
                my $l = $_;
                $l =~ s/\s+//g;
                my @lines = split( "\,", $l );
                $ft{ $lines[0] }{"bcount"}++;
                $allinsbands++;
                $ft{ $lines[0] }{"gcount"}               = 0;
                $ft{ $lines[0] }{"chr"}{ $lines[6] }     = 1;
                $ft{ $lines[0] }{"blcount"}{ $lines[3] } = 1;
                $ft{ $lines[0] }{"frpmiss"}{ $lines[1] } = 1;
                $ft{ $lines[0] }{"rvpmiss"}{ $lines[2] } = 1;
            }
        }
        close INFILE;
       #to get more than one return  
       return (\%ft,$allinsbands);
    }

sub covstat {
        my ($covfile,$ft,$totalcov) = @_;
        my %ft=%{$ft};              
        open( COVSTATFILE, "<$covfile" );
        while (<COVSTATFILE>) {
            chomp();
            if ( !(/Primer Name/) ) {
                my $l = $_;
                $l =~ s/\s//g;
                my @lines = split( "\,", $l );
                if ( $lines[0] ne "PrimerName" & $lines[0] ne "PrimerSet" ) {
                    $ft{ $lines[0] }{"cov"} = $lines[1];
                }
                if ( $lines[0] eq "PrimerSet" ) {
                    $totalcov = $lines[1];
                }
            }
        }
        close COVSTATFILE;
      return (\%ft,$totalcov); 
    }

sub covper {
        my ($covstatfile,$ft,$totalcovper) = @_;
        my %ft=%{$ft}; 

        open( COVPERFILE, "<$covstatfile" );
        while (<COVPERFILE>) {
            chomp();
            my $l = $_;
            $l =~ s/\s//g;
            my @lines = split( "\,", $l );
            if ( $lines[0] ne "PrimerName" & $lines[0] ne "PrimerSet" ) {
                $ft{ $lines[0] }{"covper"} = $lines[1];
            }
            if ( $lines[0] eq "PrimerSet" ) {
                 $totalcovper = $lines[1];
            }
        }
        close COVPERFILE;
        return (\%ft,$totalcovper);       
    }
sub reading {
       my ($gfile,$ft) = @_;
        my %ft=%{$ft}; 

        open( IGFILE, "<$gfile" );
        while (<IGFILE>) {
            chomp();
            my $l = $_;
            $l =~ s/\s//g;
            my @lines = split( "\,", $l );
            $ft{ $lines[0] }{"gcount"}++;
            $ft{ $lines[0] }{"agcount"}{ $lines[9] } = 1;
        }
        close IGFILE;
       return %ft;
    }

#return actual genes number for every primer
sub get_agene_count_and_anchror_chr
{
 my($ft)=@_;
 my %ft=%{$ft};
 my $anchc;
 my $tgenes; 
	 foreach my $k ( keys(%ft) ) {
	  $tgenes += keys( %{ $ft{$k}{"agcount"} } );
            if ( keys( %{ $ft{$k}{"chr"} } ) == 1 ) {
            $anchc++;}
	 }

 return ($tgenes,$anchc);
}

sub readinvins {
        my ($insinvfile,$ft) = @_;
        my %ft=%{$ft};    
        open( INSINVFILE, "<$insinvfile" );
        while (<INSINVFILE>) {
            chomp();
            my $l = $_;
            my @lines = split( /\s+/, $l );
            $ft{ $lines[0] }{"inv"}{ $lines[1] }++;
        }
        close INSINVFILE;
       return %ft;
    }
sub print_report_table
{
	my($ft,$outputdir)=@_;
	my %ft=%{$ft};

    open( RTFILE, ">" . $outputdir . "Report_table.csv" );
    print RTFILE "primer-name".","."foward-forms".
		","."reverse-forms".","."band-count".
		","."band-length-count".","."chr-count".
		","."genome-coverage".","."genes-count".
		","."actual-genes-count".","."inv-ins-bands\n";
    foreach my $k ( keys(%ft) ) {

        print RTFILE 
                     #primer name
                     $k . "," . 
                     #forward isomerase count
                     keys( %{ $ft{$k}{"frpmiss"} } ) . "," .
                     #reverse isomerase count
                     keys( %{ $ft{$k}{"rvpmiss"} } ) . "," . 
		     #band count
                     $ft{$k}{"bcount"} . "," .
		     #band lengths count (bands with different length)
                     keys( %{ $ft{$k}{"blcount"} } ) . "," .
                     #chromsomes count this primer hited
                     keys( %{ $ft{$k}{"chr"} } ) . "," .
                     #primer cover with bp 
		     $ft{$k}{"cov"} . "," .
                     #number of genes this primer covered 
		     $ft{$k}{"gcount"} . "," . 
                     #number of actual  genes this primer covered (no name repetation)
                     keys( %{ $ft{$k}{"agcount"} } ) . "," .
                     #Invitro bands has the same or close mw as in in silico      
		     keys( %{ $ft{$k}{"inv"} } ) . "\n";

    }
    close RTFILE;
}

1;
