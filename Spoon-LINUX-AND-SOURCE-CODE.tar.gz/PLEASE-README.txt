##########PLEASE READ CAREFULLY

############# Warning
Spoon can not handle directories with spaces in Input or Output data Directories on Windows/linux/OS
This mean :

For windows : Don not install Spoon in The C: directory
 
If Directory like this:
/home/Samman Mahmoud/Data/Files
Change to this:
/home/SammanMahmoud/Data/Files

####################NEEDED#########################
#You need to install perl 5, version 18, subversion 2 (v5.18.2) on linux 
#To install and TK Module is Required or You can run "Spoon-without-GUI.pl" which does not need to install Tk from CPAN but you need to configure your run through Config/config.info

########## INSTALL On linux

sudo sh Install.sh 

########## To Run
perl Spoon.pl

or

Spoon-without-GUI.pl     #(AFTER CONFIGURE THE Config/config.info )
#########

Spoon is free 

#########For Bugs please contact 
Smahmoud@ageri.sci.eg 
