package circosconf;
use covstatics;
use strict;
sub get_prims_n_for_inscircos
{
	my($config)=@_;
	my %config=%{$config};
        my $file=$config{"OUTDIR"}.$config{PLATDIR}."In_silico_PCR_Results.csv";
        my %insresult = covstatics::readinsresult($file);
	######## Read Primers File
	my $pfile = $config{"PRIMERSFILE"};
	my $n=1;
	my %pn;
	open(PFILE,$pfile);
		while(<PFILE>)
		{
                        
			chomp();
			my @line=split(/\s+/,$_);
                        #if this primer has hits
                        #To get primers in the same order as in primers file   
                        if(!$pn{$line[0]}&&$insresult{$line[0]})
                        {
                        $pn{$line[0]}=$n;
                        $n++;
                        }
			
		}
	close PFILE;
        return %pn;
}

sub create_PsetBand_file
{
	my ($pn,$config,$outputdir)=@_;
        my %config=%{$config}; 
	my %pn=%{$pn};
        open(BPFILE,">".$outputdir.$config{PLATDIR}."PBANDS.txt");
	foreach my $p(keys(%pn))
	{
          print BPFILE "PSET\t".($pn{$p}*10)."\t".(($pn{$p}*10)+10)."\t".$p."\n";
	}
        close  BPFILE; 
}

sub print_genes_statcircos
{
my($config,$outputdir,$areas)=@_;
my %config=%{$config};
my %areas=%{$areas};
open(INFILE,"<".$config{"OUTDIR"}.$config{PLATDIR}."Covered_genes_file.txt");
open(OUFILE,">".$outputdir.$config{PLATDIR}."GENESTITLE.txt");
while(<INFILE>)
{

  my $line=$_;
  chomp();
  $line=~s/,/\t/g;
  if($line=~/(\S+)\s+(\S+)\s+(\S+)\s+(\S+)/)
   {     
        my $gname= $4;
        my $gchr=$1;
  	my $gstr=$2;
  	my $gend=$3;   
        $gname=~s/(\S{18})\S+$/\1\.\.\./g;
         foreach my $chrarea(keys(%areas))
	 {          
          my ($mychr,$mystr,$myend)=split(/:/,$chrarea);
          $chrarea=~s/\:/\_/g;
          if($gstr>=$mystr&&$gend<=$myend&&$mychr eq $gchr)
          {
	         print OUFILE "$chrarea\t$gstr\t$gend\t".$gname."\n";  
	  }
         } 
  }
  
}
close INFILE;
close OUFILE;
}
sub print_link_Pset_hit
{
my($parray,$covarea,$pn,$outputdir,$colors,$config)=@_;
my %pn=%{$pn};
my @colors=@{$colors};
my @parray=@{$parray};
my %covarea=%{$covarea};
my %config=%{$config};
open(LFILE,">".$outputdir.$config{PLATDIR}."Links.lk");
	foreach my $p (@parray)
	{
		 foreach my $cov (keys($covarea{$p}))
		 { 
		   foreach my $amp (@{$covarea{$p}{$cov}})
		   { 
		      #remove the : for tech reasons
		      my $covc=$cov;
		         $covc=~s/\:/\_/g;  
                      #if this primer exceeds the color numbers choose random
                      if(!($colors[$pn{$p}])){$colors[$pn{$p}]=$colors[rand(12)];} 

		      print LFILE "PSET\t".(($pn{$p}-1)*10)."\t".($pn{$p}*10+10).
			"\t".$covc."\t".$amp->[0]."\t".$amp->[1]."\tcolor=".
			 $colors[$pn{$p}]."\n";

		   }
		 }
	}

close LFILE;
}

sub get_cov_stat_for_circos
{
my($covarea,$parray)=@_;
my %covarea=%{$covarea};
my @parray=@{$parray};
#primer coverage statistics
my %pcstatistics;
#primer set coverage statistics
my %pstatistics;
# Seq areacoverage statistics 
my %cstatistics;
# Total area covered by all p. set
my $tatolcover;
foreach my $p (@parray)
{

         foreach my $cov (keys($covarea{$p}))
	 {

	   foreach my $amp (@{$covarea{$p}{$cov}})
	   {
	     $pcstatistics{$p}{$cov}+=($amp->[1]-$amp->[0]);
	     $cstatistics{$cov}+=($amp->[1]-$amp->[0]);
	     $pstatistics{$p}+=($amp->[1]-$amp->[0]); 
	     $tatolcover+=($amp->[1]-$amp->[0]);
	   }
	  }
}

return (\%pcstatistics,\%pstatistics,\%cstatistics,$tatolcover);
}



sub print_circos_statics
{
my($outdir,$pcstatistics,$pstatistics,$cstatistics,$tatolcover,$config,$pn,$anchorprims)=@_;
my %pcstatistics=%{$pcstatistics};
#primer set coverage statistics
my %pstatistics=%{$pstatistics};
# Seq areacoverage statistics 
my %cstatistics=%{$cstatistics};
my %config=%{$config};
my %pn=%{$pn};
my %anchorprims=%{$anchorprims};
#mark primers with genes 
my $keycodefile=$config{"OUTDIR"}.$config{PLATDIR}."keycode.info";
my %seqkeys      = user_config::readseqkey($keycodefile);
my %insresultwithg=covstatics::getbypbyaccforstatisticsbykey($config{"OUTDIR"}.$config{PLATDIR}."In_silico_PCR_near_or_adjoin_genes.csv",\%seqkeys);
#To calcluate the coverage of the pset for this Chr/Seq
my $genlength;
open(SFILE,">".$outdir.$config{PLATDIR}."statistics_by_PCoverONTotal.txt");
open(SGFILE,">".$outdir.$config{PLATDIR}."statistics_by_PCoverONLength.txt");

open(PGFILE,">".$outdir.$config{PLATDIR}."Primers_with_Genes.txt");
open(SBFILE,">".$outdir.$config{PLATDIR}."statistics.BANDS");

foreach my $c (keys(%cstatistics))
{
    
   #get covered area info
   my ($chr,$str,$end)=split(/:/,$c);
   #the length of area needed (the all chr/seq area in general)
   my $length=($end-$str);
   # add to the area coverage
   $genlength+=$length;
   # Remove empty primers to give some space
   my %outpcstatistics = remove_non_result_ps(\%pcstatistics,$c);
   #the step for chart position as all charts must have share the area of the chromosome
   my $step=$length/(keys(%outpcstatistics)+1);
   $step = (sprintf("%.0f",$step)-1);
   my $pmn=1; 
   foreach my $p (keys(%outpcstatistics))
   {
    my $ck=$c;
    my $area=$ck; 
    $ck=~s/:/\_/g;

    # The area covered by this primer compared the area covered for all chr by all primers   
    print SFILE "$ck\t".($pmn*$step)."\t".(($pmn*$step)+$step)."\t".sprintf("%.8f",(($pcstatistics{$p}{$c}/$cstatistics{$c})*100))."\n";
    # the area covered by this primer compared the length of the all area
    print SGFILE "$ck\t".($pmn*$step)."\t".(($pmn*$step)+$step)."\t".sprintf("%.8f",(($pcstatistics{$p}{$c}/$length)*100))."\n";
    # print tne name of the primers beneath every charts
    print SBFILE "$ck\t".($pmn*$step)."\t".(($pmn*$step)+$step)."\t".$p;
    #if anchored make it red
    if($anchorprims{$p}{"area"} eq $area){print SBFILE "\tcolor=red,label_font=bold\n"}else{print SBFILE "\n";}
     if($insresultwithg{$p}{$chr}){
     print PGFILE "$ck\t".($pmn*$step)."\t".(($pmn*$step)+$step)."\t"."0"."\n";
     }
    
    $pmn++; 
   }

}

#print for the major pset charts (in the middle of the circos
foreach my $p (keys(%pstatistics))
{

  print SFILE "PSET\t".($pn{$p}*10)."\t".($pn{$p}*10+10)."\t".sprintf("%.8f", (($pstatistics{$p}/$tatolcover)*100))."\n";
  print SGFILE "PSET\t".($pn{$p}*10)."\t".($pn{$p}*10+10)."\t".sprintf("%.8f", (($pstatistics{$p}/$genlength)*100))."\n";  
  print SBFILE "PSET\t".($pn{$p}*10)."\t".($pn{$p}*10+10)."\t".$p."\n";
} 
close SFILE;
close SBFILE;
close SGFILE;
close PGFILE;
}

########In order to remove primers wtih no results on this chr
sub remove_non_result_ps
{
my($pcstatistics,$c)=@_;
my %pcstatistics=%{$pcstatistics};
my %outpcstatistics;
foreach my $p(keys{%pcstatistics})
{
     if($pcstatistics{$p}{$c})
     {
      $outpcstatistics{$p}{$c}=$pcstatistics{$p}{$c};
     }
}
return %outpcstatistics;
}
sub print_def_statcircos
{
my($areas,$pn,$outputdir,$config)=@_;
my %areas=%{$areas};
my %pn=%{$pn};
my %config=%{$config};
#Create DEF for SEQ
my $chrn=1;
open( DFILE, ">".$outputdir.$config{PLATDIR}."DEF.txt" );
foreach my $r (keys(%areas))
{
 
 my ($chr,$str,$end)=split(/:/,$r);
 $r=~s/:/\_/g;
 print DFILE "chr\t-\t$r\t$r\t$str\t$end\t"."Chr".$chrn."\n";
 $chrn++;
}
 print DFILE "chr\t-\tPSET\tPSET\t0\t".((keys(%pn)+1)*10)."\tPSET\n";
 close DFILE;
}
sub print_hitlinks_statcircos
{
my($colors,$config,$outputdir,$pn,$areas)=@_;
my @colors=@{$colors};
my %config=%{$config};
my %pn=%{$pn};
my %areas=%{$areas};
open(INGFILE,"<".$config{"OUTDIR"}.$config{PLATDIR}."In_silico_PCR_near_or_adjoin_genes.csv");
open(HLFILE,">".$outputdir.$config{PLATDIR}."HITLINKS.txt");
my $keycodefile=$config{"OUTDIR"}.$config{PLATDIR}."keycode.info";
my %seqkey      = user_config::readseqkey($keycodefile);
while(<INGFILE>)
{
        chomp();
        my @line=split("\,",$_);

         foreach my $chrarea(keys(%areas))
	 {        
          my ($mychr,$mystr,$myend)=split(/:/,$chrarea);
          my ($gchr,$gstr,$gend,$p)=($seqkey{$line[6]},$line[7],$line[8],$line[0]); 
          if(!($colors[$pn{$p}])){$colors[$pn{$p}]=$colors[rand(12)];}  
           if($gstr>=$mystr&&$myend>=$gend&& $gchr eq $mychr)
           {   
                $chrarea=~s/\:/\_/g;
                my $hitline = $chrarea."\t".$gstr."\t".$gend."\t"."fill_color=".$colors[$pn{$p}]."\n";
	 	print HLFILE $hitline;
           }
         } 
}
close INGFILE;
close HLFILE;
}


1;
