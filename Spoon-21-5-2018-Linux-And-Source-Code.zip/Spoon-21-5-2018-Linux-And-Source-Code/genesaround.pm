package genesaround;
use user_config;
use strict;
use MainSpoon;

sub getgenesaround
{
my ($config)=@_;
my %config=%{$config};
my $keycodefile=$config{"OUTDIR"}.$config{PLATDIR}."keycode.info";
my $insfile=$config{"OUTDIR"}.$config{PLATDIR}."In_silico_PCR_Results.csv";
my $glocfile    = $config{"OUTDIR"}.$config{PLATDIR}."Seq_Genes_Loc.txt";
my %seqkey      = user_config::readseqkey($keycodefile);
my %pamps       = MainSpoon::getbypbyacc( \%config);
my %genfile     = MainSpoon::readGFile($glocfile);
my  %Covered_genes_file ;
my  %Amplicons_with_genes;
my $outdir  = $config{"OUTDIR"}.$config{PLATDIR};
my $outfile = $outdir. "In_silico_PCR_near_or_adjoin_genes.csv";
my $covgfile = $outdir."Covered_genes_file.txt";
my $ampgfile  =$outdir."Amplicons_with_genes.csv";
my $gooddis = $config{"GENEDIST"};
open (GINSFILE,">$outfile");
foreach my $key(keys(%genfile))
{ 

              foreach my $gene (@{$genfile{$key}}){                        
                        my $genstar = $gene->{str};
                        my $genend = $gene->{end};
                        my $acc = $gene->{acc};
                        my @hits = searchprimhits($acc,$genstar,$genend,$gooddis,\%pamps); 
                        my $ishit = 0; 
                        foreach my $amp (@hits)
                        {
                        
                        $ishit = 1; 
                        my $line = $amp->{"pnam"} .",".   
                                   $amp->{"pf"}   .",". 
                                   $amp->{"pr"}   .",".
                                   $amp->{"aml"}  .",".
                                   $amp->{"fhmis"} .",".
                                   $amp->{"rhmis"} .",".
                                   $amp->{"seqnam"} .",".
                                   $amp->{"fpos"}  .",".
                                   $amp->{"rpos"}  ;
                                   my $hitmapline=$amp->{"pnam"}.",".$amp->{"aml"}.",".$acc.",".$amp->{"fpos"}.",".$amp->{"rpos"};
                                   $Amplicons_with_genes{$hitmapline}=1;
                                   $gene->{pro}=~s/,//g;             
                        print GINSFILE $line.",".$gene->{pro}."\n";                         
                        }
                         if($ishit==1){my $h=$acc."\t".$genstar."\t".$genend."\t".$gene->{pro};$Covered_genes_file{$h}=1;}
                        };
}
close GINSFILE;

####### Covered genes file
open (GINSFILE,">".$covgfile);
foreach my $myh (keys(%Covered_genes_file)){print GINSFILE $myh."\n";}
close GINSFILE;

####### Amplicons with genes hit file
open (AMPFILE,">".$ampgfile);
foreach my $myamp (keys(%Amplicons_with_genes)){print AMPFILE $myamp."\n";}
close AMPFILE;
}

sub searchprimhits
{  
my ($acc,$genstr,$genend,$gooddis,$pamps) = @_;
my @genhits=();
my %pamps=%{$pamps};
foreach my $prim (keys(%pamps))
{

if($prim ne  "PrimerSet")
{
foreach my $amp (@{$pamps{$prim}{$acc}})
{    
  my $rdis =$amp->{"fpos"}-$genstr;
  my $fdis =$amp->{"rpos"}-$genend;
  $rdis =~s/-//g;
  $fdis =~s/-//g;
  if($fdis<=$gooddis ||$rdis<=$gooddis)
  {
    push  (@genhits,$amp);
    
  }
}
}
}
return @genhits;
}

sub createglocfilefromlist
{
    my($config)=@_;
    my %config=%{$config};
    my $glocfile=$config{"OUTDIR"}.$config{PLATDIR}."Seq_Genes_Loc.txt";
    my @glsifiles=get_glist_in_dir(\%config);
    clearlisttogenefile($glocfile);
    foreach my $file(@glsifiles)
    {
     listtogenefile($config{"GENBANKDIR"}.$config{PLATDIR}.$file,$glocfile,\%config,$file);
    }
}
sub clearlisttogenefile
{
my($outfile)=@_;
open(GLOCFILE,">".$outfile);
close GLOCFILE;
}

sub listtogenefile
{
my($listfile,$outfile,$config,$filename)=@_;
my %config=%{$config};

my $keycodefile=$config{"OUTDIR"}.$config{PLATDIR}."keycode.info";
my %seqkey      = user_config::readseqkey($keycodefile);
my $dataname=$filename;
   $dataname=~s/\.list//g; 
open(LFILE,$listfile);
open(GLOCFILE,">>".$outfile);
while(<LFILE>)
{
chomp();
my @line=split(/\s+/,$_);
print $_."\n";
if($seqkey{$line[0]})
{$line[0]=$seqkey{$line[0]}};
print GLOCFILE join("\t",@line)."\t".$dataname."\n";
}

close GLOCFILE;
close LFILE;
}

sub get_glist_in_dir
{
    my($config)=@_;
    my %config=%{$config};
    my $dir =$config{"GENBANKDIR"}; 
    opendir DIR, $dir or die "cannot open dir $dir: $!";
    my @files = readdir DIR;
    my @fileslist; 
    foreach my $file (@files) {
        if ( $file =~ /.list$/g ) {
        push(@fileslist,$file);         
        }
    }
    closedir DIR;
    return @fileslist;
}

sub createglocfilefromgb
{
    my($config)=@_;
    my %config=%{$config};
    my @filelist=get_gb_in_dir(\%config);
    my $glocfile=$config{"OUTDIR"}.$config{PLATDIR}."Seq_Genes_Loc.txt";
    cleargenbanktogenefile($glocfile);
    foreach my $file(@filelist)
    {
      genbanktogenefile($config{"GENBANKDIR"}.$config{PLATDIR}.$file,$glocfile,\%config);
    }   

}
sub get_gb_in_dir
{
    my($config)=@_;
    my %config=%{$config};
    my $dir =$config{"GENBANKDIR"}; 
    opendir DIR, $dir or die "cannot open dir $dir: $!";
    my @files = readdir DIR;
    my @fileslist; 
    foreach my $file (@files) {
        if ( $file =~ /.gb$/g ) {
        push(@fileslist,$file);         
        }
    }
    closedir DIR;
    return @fileslist;
}

sub cleargenbanktogenefile
{
my($outfile)=@_;
open(MYGFILES,">$outfile");
close MYGFILES;

}
sub genbanktogenefile
{
my($genfile,$outfile,$config)=@_;
my %config=%{$config};
my $keycodefile=$config{"OUTDIR"}.$config{PLATDIR}."keycode.info";
my %seqkey      = user_config::readseqkey($keycodefile);
my $genestart_end = "";
my $genestart ="";
my $geneend="";
my $start = "";
my $end   = "";
my $gene  = "";
open( GG, "<$genfile" );
open(MYGFILES,">>$outfile");
my $Locus   = "";
my $printed = 0;
while (<GG>) 
{

    if (/[>|<]*(\d+)\.\.[>|<]*(\d+)/) 
    {
        $start = $1;
        $end   = $2;  
        if (/gene/) 
        {
            $genestart = $start;
            $geneend   = $end;
            $printed = 0;
        }
    }
    
    elsif (/product\=\"([\S|\s]+)/) {
        $genestart_end =~ s/\n//g;
        $gene = $1;
        $gene =~s/"//g;
        $gene =~ s/\s+$//g;
        $gene =~ s/\s/_/g;
         
       if($printed==0)
       { 
          print MYGFILES $Locus . "\t" . $genestart . "\t" . $geneend . "\t" . $gene."\t"."gene"."\n";
          $printed = 1;
       }
      }
    elsif (/LOCUS\s+(\S+)/)
    {
        $Locus = $1;
        if($seqkey{$Locus})
        {  
         $Locus = $seqkey{$Locus};
        }
    }
}
close GG;
close MYGFILES;
}
1;
