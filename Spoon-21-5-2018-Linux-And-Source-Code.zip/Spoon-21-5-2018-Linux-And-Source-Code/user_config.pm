package user_config;
use Config;
use strict;
sub readsystem {
    my $plat="/"; 
    if (!($Config{osname} =~ /linux/) ) {
        $plat = "\\";
    }
    return $plat;
}

sub readconfigfile {
    my ($confile)=@_;
    
    open( FILE, "$confile" );
    my %config;
    my %seqinfo;
    while (<FILE>) {
        chomp();          

        if (/^OUTDIR\=([\s|\S]+)/)      { $config{"OUTDIR"}= "$1";}
        if (/^FASTADIR\=([\s|\S]+)/) { $config{"FASTADIR"} = "$1";}  
        if (/^GENBANKDIR\=([\s|\S]+)/) { $config{"GENBANKDIR"} = "$1"; }  
        if (/^CREATEDIR\=([\s|\S]+)/) {  $config{PFOLDER}= $1; }
        if (/^SNPFILE\=([\s|\S]+)/) {  $config{SNPFILE}= "$1"; }
        if (/^PRIMERSFILE=([\s|\S]+)/)      { $config{"PRIMERSFILE"}= "$1"; }
        if (/^MAPFOLDER\=([\s|\S]+)/) {  $config{"MAPFOLDER"} = "$1"; }          
        if (/^PCOVAREA\=([\s|\S]+)/) {  $config{"PCOVAREA"} = "$1"; }  
        if (/^INVITROPCR\=([\s|\S]+)/) {  $config{INVITROPCR}= "$1" }


        if (/^UPSTEAREM=(\S+)/)  { $config{"UPSTEAREM"}  = $1 }
        if (/^DOWNSTREAM=(\S+)/) { $config{"DOWNSTREAM"} = $1 }
        if (/^PMISS=(\S+)/)      { $config{"PMISS"}      = $1 }
        if (/^MAXBL=(\S+)/)      { $config{"MAXBL"}      = $1 }
        if (/^MINBL=(\S+)/)      { $config{"MINBL"}      = $1 }
        if (/^CMISS=(\S+)/)      { $config{"CMISS"}      = $1 }
        if (/^P3PRIMEMISSN=(\d+)/)      { $config{"P3PRIMEMISSN"}      = $1 }
    
        if (/^CHRKEY=(\S+)/)      { $config{"CHRKEY"}      = "$1" }
        if (/^ORDERACCORDINGTO=(\S+)/){ $config{"ORDERACCORDINGTO"}      = $1 }  
        if (/^GFBLAST=(\S+)/)      { $config{"GFBLAST"}      = $1 }
        if (/^MAXGAPBAMP=(\S+)/) { $config{"MAXGAPBAMP"} = $1 }
        if (/^DOINSILICO=(\S+)/) { $config{"DOINSILICO"} = $1 }
        if (/^GFGENBANK=(\S+)/) { $config{"GFGENBANK"} = $1 }
        if (/^AlIGNINVITROTO=(\S+)/) { $config{"AlIGNINVITROTO"} = $1 }
        if (/^GENESAROUND=(\S+)/) { $config{"GENESAROUND"} = $1 }  
        if (/^PCRSTAT=(\S+)/) { $config{"PCRSTAT"} = $1 }  
        if (/^PCRCIRCOS=(\S+)/) { $config{"PCRCIRCOS"} = $1 }  
        if (/^PCRALIGN=(\S+)/) { $config{"PCRALIGN"} = $1 }  
        if (/^EXTRACTAMPS=(\S+)/) { $config{"EXTRACTAMPS"} = $1 }  
        if (/^BLAST=(\S+)/) { $config{"BLAST"} = $1 }
        if (/^GENEDIST=(\S+)/) {  $config{"GENEDIST"} = $1 }        
        if (/^SNPDIST=(\S+)/) {  $config{"SNPDIST"} = $1 }        
        if (/^SNPDATABASETYPE=(\S+)/) {  $config{"SNPDATABASETYPE"} = $1 }   
        if (/^KASPFOR=(\S+)/) {  $config{"KASPFOR"} = $1 }       
        if(/^DOSSR=(\S+)/) {  $config{"DOSSR"} = $1 }
        if (/^MAPCOMPARE\=(\S+)/) {  $config{"MAPCOMPARE"} = "$1" }         

        if (/^ANNOTEFILETYPE\=(\S+)/) {  $config{ANNOFILE}= $1 }
        if (/^INV\-INS\-Miss\=(\S+)/) {  $config{INVINSMiss}= $1 }

        if (/^CREATEKASP\=(\S+)/) {  $config{CREATEKASP}= $1 }
           
    }      
    close FILE;
    $config{PLATDIR} = readsystem();
    if ( $config{"PCOVAREA"} =~ m/All/g ) {
        $config{"PCOVAREA"} = $config{"OUTDIR"}.$config{PLATDIR}."ALL\-CovArea.info";
      } 
    return %config;
}
my $chrn = 1;
sub createinfofiles {
    my($config)=@_;
    my %config=%{$config};
    clearinfo(\%config);
    clear_chr_keycode(\%config);
    $chrn=1; 
    my $dir = $config{FASTADIR};  
    my @fafiles = get_fasta_in_dir($dir,\%config);    
    
    foreach my $file(@fafiles)
    {

                   
           #take every fasta file and fitch seq(s) in it 
           my %info = get_seq_info_in_fasta_file($dir.$config{PLATDIR}.$file);
           #print info
           printinfo(\%info,\%config);
           if ( $config{"ORDERACCORDINGTO"} ne "MANUAL" ) 
	   {
            create_chr_keycode(\%info,\%config,$chrn);
	   }
     $chrn++;         
    } 

}

sub create_chr_keycode
{
    my($info,$config,$chrn)=@_;
    my %config=%{$config};
    my %info=%{$info};
    my $SeqK = $config{"CHRKEY"} ;
    open(KEYFILE,">>".$config{"OUTDIR"}.$config{PLATDIR}."keycode.info");
    foreach my $i (keys(%info))
    {
         print  KEYFILE $i.";".$SeqK.$chrn."\n";
         if($i=~m/(ref|gb)\|(\w+\S+)\|/g)
           {
            my $hit=$2; 
            print  KEYFILE $hit.";".$SeqK.$chrn."\n";
            $hit=~s/\.\d+//g;
            print  KEYFILE $hit.";".$SeqK.$chrn."\n";         
           }
           
             
         $chrn++;  
    }
    close KEYFILE;
}
sub clear_chr_keycode
{
    my($config)=@_;
    my %config=%{$config};
    open(KEYFILE,">".$config{"OUTDIR"}.$config{PLATDIR}."keycode.info"); 
    close KEYFILE;
}
sub get_fasta_in_dir
{
    my($dir,$config)=@_;
    my %config=%{$config};
    opendir DIR, $dir or die "Please Select Config File !!\n";
    my @files = readdir DIR;
    my @fileslist; 
    foreach my $file (@files) {
        if ( $file =~ /.fasta$/g ) {
        push(@fileslist,$file);
         
        }
    }
    closedir DIR;
    return @fileslist;
}
sub printinfo
{
	my($info,$config)=@_;
	my %config=%{$config};
	my %info=%{$info};
	open(INFOFILE,">>".$config{"OUTDIR"}.$config{PLATDIR}."seq.info");
	foreach my $i (keys(%info))
	{
	 print INFOFILE $i.";".$info{$i}."\n";
        }
        close  INFOFILE;          
        if ( $config{"PCOVAREA"} =~ m/ALL\-CovArea\.info/g ) {        
         open(COVFILE,">>".$config{"OUTDIR"}.$config{PLATDIR}."ALL\-CovArea.info");         
	  foreach my $i (keys(%info))
	  {         
	  print COVFILE $i.":0:".$info{$i}."\n";
          }
         close  COVFILE;
        }
}

sub readseqkey {
    my ($file)=@_;
    my %seqkey;
    open( FILE, $file );
    while (<FILE>) {
        chomp();
        my @line = split( ";", $_ );
        $seqkey{ $line[0] } = $line[1];
    }
    close FILE;
    return %seqkey;
}


sub readseqinfo {
    my ($file)=@_;
    my %seqinfo;
    open( MYINFOFILE, "<".$file ) ;
    while (<MYINFOFILE>) {
        chomp();
        my @line = split( ";", $_ );
        $seqinfo{ $line[0] } = $line[1];      
    }
    close MYINFOFILE;
    return %seqinfo;
}

sub readcov
{
my($file)=@_;
open MYFILE,"<$file";
my %acccov;
while(<MYFILE>)
{
   if ( $_ =~ /(\S+)\:(\d+)\:(\d+)/ ) {
              push( @{ $acccov{$1} }, [ $2, $3, $& ,$1] );
                }
}
close MYFILE;
return %acccov
}

sub clearinfo
{
	my($config)=@_;
	my %config=%{$config};
	open(INFOFILE,">".$config{"OUTDIR"}.$config{PLATDIR}."seq.info");
        close  INFOFILE;

      if ( $config{"PCOVAREA"} =~ m/ALL/g ) {
        open(COVFILE,">".$config{"OUTDIR"}.$config{PLATDIR}."ALL\-CovArea.info");         		
        close  COVFILE;
        }

}
sub get_seq_info_in_fasta_file
{
 
            my($file)=@_;
            my %info;
            my %seq;
            my $acc;
            open( MYFFILE, "<$file" );
            while (<MYFFILE>) {
                chomp(); 
                if (/>(\S+)/) {
                 $acc = $1;
                 }
                 else
                 {
                  $seq{$acc}.=$_; 
                 }         
            }
            close MYFFILE;
            foreach my $s(keys(%seq))
            {
             $info{$s}=length($seq{$s}); 
            }     
%seq={};
return %info;        
}

sub get_seq_in_fasta_file
{

            my($file)=@_;
            my %info;
            my %seq;
            my $acc;
            open( MYFFILE, "<$file" );
            while (<MYFFILE>) {
                chomp(); 
                if (/>(\S+)/) {
                 $acc = $1;
                 }
                 else
                 {
                  $seq{$acc}.=$_; 
                 }         
            }
            close MYFFILE;
  	    return %seq;        

}

1;
