package comparemaps;
use MainSpoon;
use user_config;
use strict;
#print links file and out file and return LGs and Chrs 
sub print_links_compare_file
{
my($ins_results,$p_map,$outdir,$seqkeys,$pn)=@_;
mkdir $outdir;
open(LFILE,">".$outdir."Links.txt");
open(PFILE,">".$outdir."Ptitles.txt");
my @colors=MainSpoon::colors();
my %pn=%{$pn};

my %p_map=%{$p_map};
my %seqkeys=%{$seqkeys};
my %ins_results=%{$ins_results};
#compare and get shared Ps
my %chrs_here;
my %lgs_here;
foreach my $p(keys(%ins_results))
{
 if($p_map{$p}){

  foreach my $amp(@{$ins_results{$p}})
  {
     $chrs_here{$amp->{"seqnam"}}=1; 
     $lgs_here{$p_map{$p}{"lgname"}}{$amp->{"seqnam"}}++;
     my $lgpos=int($p_map{$p}{"pos"});
      if(!($colors[$pn{$p}])){$colors[$pn{$p}]=$colors[rand(12)];}
     print LFILE $p_map{$p}{"lgname"}."\t".$lgpos."\t".($lgpos+1)."\t".$seqkeys{$amp->{"seqnam"}}."\t".$amp->{"fpos"}."\t".$amp->{"rpos"}."\tcolor=".$colors[$pn{$p}]."\n";
     print PFILE $p_map{$p}{"lgname"}."\t".$lgpos."\t".($lgpos+1)."\t".$p."\n";
     print PFILE $seqkeys{$amp->{"seqnam"}}."\t".$amp->{"fpos"}."\t".$amp->{"rpos"}."\t".$p."\n";    
  } 
 }
}
close LFILE;
close PFILE;
return (\%chrs_here,\%lgs_here);
}

sub lg_chr_assign_file
{
my($lgs_here,$seqkeys,$outdir)=@_;
my %lgs_here=%{$lgs_here};
my %seqkeys=%{$seqkeys};

open(FILE,">".$outdir."LG-ASSIGNMENT-Report.txt");
print FILE "LG-Name.\t"."Chr-code"."Seq-Acc"."\tPrimers-Match-Count\n";
foreach my $lg (keys(%lgs_here))
{

foreach my $chr (keys($lgs_here{$lg}))
{
  print FILE $lg."\t".$seqkeys{$chr}."\t".$chr."\t".$lgs_here{$lg}{$chr}."\n";
}
print FILE "#################################################\n";
}

close FILE;

}


sub get_maps_in_dir
{
my($dir)=@_;
my @fileslist;
    opendir DIR, $dir or die "cannot open dir $dir: $!";
    my @files = readdir DIR;
    my @fileslist; 
    foreach my $file (@files) {
        if ( $file =~ /.map$/g ) {
           push(@fileslist,$file);
        }
    }
closedir DIR;
return @fileslist;
}
sub print_def
{
my($chrs_here,$lgs_here,$seqkeys,$seqinfos,$lginfo,$OutDir)=@_;
my %chrs_here=%{$chrs_here};
my %lgs_here=%{$lgs_here};
my %seqkeys=%{$seqkeys};
my %seqinfos=%{$seqinfos};
my %lginfo=%{$lginfo};
my $chr_n=1;
open(DEFFILE,">".$OutDir."DEF.txt");
foreach my $r(keys(%chrs_here))
{

  # print $seqkeys{$r}."\t".$seqinfos{$r}."\n";
   print DEFFILE "chr\t-\t".$seqkeys{$r}."\t".$seqkeys{$r}."\t0\t".$seqinfos{$r}."\tChr$chr_n\n";
   $chr_n++;
}
#print LGs
foreach my $lg(keys(%lgs_here))
{
    my $lgl=int($lginfo{$lg});
    print DEFFILE "chr\t-\t".$lg."\t".$lg."\t0\t".($lgl+1)."\tChr$chr_n\n";
    $chr_n++;



}
close DEFFILE;

}



sub read_maps
{
my($files,$filepath)=@_;
my %lginfo;
my %p_map;
my @files=@{$files};

foreach my $f(@files)
{

 my @out_array=read_map($filepath.$f,\%p_map,\%lginfo,$f);
 %p_map=%{$out_array[0]};
 %lginfo=%{$out_array[1]};
}
return (\%p_map,\%lginfo);
}

#retrun primers map pos and lg infos;
sub read_map
{
my ($mapfile,$p_map,$lginfo,$fname)=@_;
$fname=~s/\.map//g;
my %lginfo=%{$lginfo}; 
my %p_map=%{$p_map};
 
open(FILE,$mapfile);
while(<FILE>)
{
  chomp();
  if(/(\S+)\s+(\S+)/)
  { 
    $p_map{$2}{"pos"}=$1;
    $p_map{$2}{"lgname"}=$fname; 
    #to get the lg length   
    if($lginfo{$fname}<$1)
    {
       $lginfo{$fname}=$1;
    }
  }
}
close FILE;
return (\%p_map,\%lginfo);
}


1;
