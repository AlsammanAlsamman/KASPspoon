echo "Creating Spoon C searcher tool"
gcc  bin/INSILICO.c -o bin/Spoon-C.out
echo "Making it make executable"
chmod +x bin/Spoon-C.out
