mkdir "Config";
########## Needed Modules
use warnings;
use strict;
use Tk;
use LWP::UserAgent;
use File::Path qw(make_path remove_tree);
use Tk::Dialog;
use File::Basename;
use Data::Dumper;
use Config;
########## Spoon Modules
use MainSpoon;
use genesaround;
use user_config;
use covstatics;
use extractamps;
use insinvcompare;
use templates;
use circosconf;
use report;
use standards;
use MISA;
use comparemaps;
use KASPassay;
##########
my %config;
my $lastD;
##########

####### List of Checkboxes and thier defualt values
my @TEXTBOXLIST;

my $Annot       = "GB";
my $KASPpt      = "ALL";
my $SNPFILETYPE = "VCF";
my $OUTDIR;
################# DefaultParams
my %paramsdefault;
$paramsdefault{"PMISS"}            = 0;
$paramsdefault{"CMISS"}            = 0;
$paramsdefault{"P3PRIMEMISSN"}     = 3;
$paramsdefault{"MINBL"}            = 50;
$paramsdefault{"MAXBL"}            = 1500;
$paramsdefault{"UPSTEAREM"}        = 1000;
$paramsdefault{"DOWNSTREAM"}       = 1000;
$paramsdefault{"MAXGAPBAMP"}       = 50;
$paramsdefault{"GENEDIST"}         = 1000;
$paramsdefault{"SNPDIST"}          = 0;
$paramsdefault{"INV-INS-Miss"}     = 10;
$paramsdefault{"ORDERACCORDINGTO"} = "GI";
$paramsdefault{"CHRKEY"}           = "Chr";
$paramsdefault{"AlIGNINVITROTO"}   = "INS";
$paramsdefault{"definition(unit_size,min_repeats):"}="1-10 2-6 3-5 4-5 5-5 6-5";
$paramsdefault{"interruptions(max_difference_between_2_SSRs):"}="100";
                
####### widgets positions

####### Main Windows
my $mw = MainWindow->new(
    -title  => "Spoon",
    -width  => '510',
    -relief => 'flat',
    -height => '550'
);
$mw->Button( -text => 'Go Taste', -command => \&GOGO )
  ->place( -x => 230, -y => 440 );
$mw->resizable( 0, 0 );
$mw->withdraw;
$mw->Popup;
####################################MENUBAR############################
my $mbar = $mw->Menu();
$mw->configure( -menu => $mbar );
my $processb = $mbar->cascade( -label => "Process", -underline => 0, -tearoff => 0 );
$processb->command(
    -label     => "Preferences",
    -underline => 0,
    -command   => \&paramwin
);

my $helpb = $mbar->cascade( -label => "Help", -underline => 0, -tearoff => 0 );
$helpb->command( -label => "About", -underline => 0, -command => \&helpwin );




my $ProgText =
  $mw->Text( -takefocus => 1, -relief => 'flat', -width => '70', -height => 4 )
  ->place( -x => 6, -y => 480 );

#######################################################################
################################Main Window############################

######### Main Paramters
my @choosen_processes;
my @choosen_dir_files;
my @params;
############## Main ###########################
my @cbt  = standards::win1_chick_buttons_text();
my $Move = 0.5;
my $GB;
my $LIST;
my $KASPG;
my $KASPALL;
my $SNPL;
my $SNPVCF;

foreach my $cb (@cbt) {
    my $process = $mw->Checkbutton(
        -onvalue  => 'YES',
        -offvalue => 'NO',
        -text     => $cb->[0],
    )->place( -x => 10, -y => $Move * 25 );
    $process->deselect();
    push( @choosen_processes, [ $process, $cb->[1] ] );

    if ( $cb->[0] =~ m/annotation/g ) {
        $GB = $mw->Radiobutton(
            -text     => 'GB',
            -value    => "GB",
            -variable => \$Annot
        )->place( -x => 380, -y => $Move * 25 );
        $LIST = $mw->Radiobutton(
            -text     => 'List',
            -value    => "LIST",
            -variable => \$Annot
        )->place( -x => 430, -y => $Move * 25 );
    }

    if ( $cb->[0] =~ m/KASP/g ) {
        $KASPG = $mw->Radiobutton(
            -text     => 'WithGenesHit',
            -value    => "G",
            -variable => \$KASPpt
        )->place( -x => 180, -y => $Move * 25 );
        $KASPALL = $mw->Radiobutton(
            -text     => 'All',
            -value    => "ALL",
            -variable => \$KASPpt
        )->place( -x => 330, -y => $Move * 25 );
    }
    $Move++;
}

my @dir_files = standards::win1_file_dir_label();

foreach my $df (@dir_files) {

    my $df_label = $mw->Label(
        -pady    => '1',
        -relief  => 'flat',
        -padx    => '1',
        -state   => 'normal',
        -justify => 'center',
        -text    => $df->[0],
    )->place( -x => 13, -y => $Move * 25 );

    my $enter = standards::win1whatentery( $df->[0] );
    if ( $df->[0] =~ m/All/g ) { $enter = "File or leave (All)" }
    my $df_entery = $mw->Entry(
        -width      => '35',
        -background => "white",
        -relief     => 'sunken',
        -state      => 'normal',
        -justify    => 'left',
        -text       => 'Click to Select ' . $enter,
    )->place( -x => 230, -y => $Move * 25 );

    push( @choosen_dir_files, [ $df_entery, $df->[1] ] );

    if ( $enter =~ m/File/g ) {
        $df_entery->bind( "<Button-1>", [ \&get_file, $df_entery ] );
    }

    if ( $enter =~ m/Directory/g ) {
        $df_entery->bind( "<Button-1>", [ \&getDir, $df_entery ] );
    }

    if ( $df->[0] =~ m/SNP/g ) {
        $SNPL = $mw->Radiobutton(
            -text     => 'List',
            -value    => "LIST",
            -variable => \$SNPFILETYPE
        )->place( -x => 100, -y => $Move * 25 );
        $SNPVCF = $mw->Radiobutton(
            -text     => 'VCF',
            -value    => "VCF",
            -variable => \$SNPFILETYPE
        )->place( -x => 150, -y => $Move * 25 );
    }

    $Move++;
}

####################### PREFERENCES ######################################
sub paramwin {
    my $win2 = $mw->Toplevel(
        -width  => '350',
        -relief => 'flat',
        -height => '610',
        -title  => "Preferences"
    );
    $win2->resizable( 0, 0 );
    $win2->withdraw;    #avoid the jumping window bug
    $win2->Popup;
######### Get Params Names
    my @labelsText = standards::paramlabelstext();
########### Create
########## LABELS
    my $pnu = 0;
    foreach (@labelsText) {
        $win2->Label(
            -pady    => "1",
            -relief  => "flat",
            -padx    => "1",
            -state   => "normal",
            -justify => "center",
            -text    => $_,
        )->place( -x => 0, -y => ( $pnu++ * 25 ) );
    }

########## TextBoxes
    my @TextBoxs = standards::paramtextboxdefault();
    my $pnx = 0;
    foreach (@TextBoxs) {
        if ( $_ ne "" ) {
            my $p = $_->[0];
            my $t = $p;
            $t =~ s/\=//g;
            if ( !( $t =~ m/AlIGNINVITROTO/g ) ) {
                my $PARAMTXT = $win2->Entry(
                    -width      => '10',
                    -relief     => 'sunken',
                    -state      => 'normal',
                    -justify    => 'left',
                    -text       => $paramsdefault{$t},
                    -background => "white",
                )->place( -x => 250, -y => ( $pnx * 25 + 23 ) );
                push( @params, [ $PARAMTXT, $p ] );
            }          
            else {
                my $AlIGNINVITROTOlb1 = $win2->Radiobutton(
                    -text     => 'All',
                    -value    => "INS",
                    -variable => \$paramsdefault{"AlIGNINVITROTO"}
                )->place( -x => 200, -y => ( $pnx * 25 + 23 ) );
                my $AlIGNINVITROTOlb2 = $win2->Radiobutton(
                    -text     => 'Genic',
                    -value    => "INS-G",
                    -variable => \$paramsdefault{"AlIGNINVITROTO"}
                )->place( -x => 250, -y => ( $pnx * 25 + 23 ) );
            }
        
        }

        $pnx++;
    }

    my $cancel_button =
      $win2->Button( -text => "cancel", -command => sub { $win2->destroy } )
      ->place( -x => 200, -y => 570 );
    my $apply_button = $win2->Button(
        -text    => "Apply",
        -command => sub {
            foreach my $g (@params) {
                my $p = $g->[1];
                $p =~ s/\=//g;
                if ( !( $p =~ m/AlIGNINVITROTO/g ) ) {
                    $paramsdefault{$p} = $g->[0]->get();
                }
            }
            $win2->withdraw;
        }
    )->place( -x => 100, -y => 570 );
}

########################### Help Window

sub helpwin {
    my $win3 = $mw->Toplevel(
        -width  => '350',
        -relief => 'flat',
        -height => '220',
        -title  => "About"
    );

#my $b2 = $win2 -> Button (-text=>"quit", -command=>sub { exit }) -->place( -x => 230, -y => 540 );
    $win3->resizable( 0, 0 );
    my $AGERILOGO  = $mw->Photo( -file => "AGERI.gif" );    #get first one
    my $ICARDALOGO = $mw->Photo( -file => "ICARDA.gif" );   #get first one
    my $AGERI =
      $win3->Label( -width => '300', -image => $AGERILOGO )
      ->place( -x => 20, -y => 60 );
    my $ICARDA =
      $win3->Label( -width => '300', -image => $ICARDALOGO )
      ->place( -x => 20, -y => 130 );
    my $var8d = $win3->Label(
        -pady    => '1',
        -width   => '50',
        -relief  => 'sunken',
        -state   => 'normal',
        -justify => 'left',
        -relief  => 'flat',
        -padx    => '1',
        -text    => 'Alsamman M. Alsamman	smahmoud@ageri.sci.eg
Shafik D. Ibrahim     	shafikdarwish@ageri.sci.eg
Hamwieh Aladdin	                   a.hamwieh@cgiar.org',
    )->place( -x => 0, -y => 0 );

    $win3->withdraw;    #avoid the jumping window bug
    $win3->Popup;
}
########################################################
sub GOGO {
    create_conf();
    runspoon();
    Processfinished($mw);
}

sub create_conf {
    $OUTDIR = $choosen_dir_files[0]->[0]->get();
    if ( $OUTDIR =~ /Click/g ) {
        $mw->Dialog(
            -title          => 'Error',
            -text           => 'Please select output Directory',
            -default_button => 'cancel',
            -buttons        => ['cancel'],
            -bitmap         => 'error'
        )->Show();
        return;
    }

    open( CONFILE, ">" . $OUTDIR . "/config.info" );

    foreach my $p (@choosen_processes) {
        print CONFILE $p->[1] . "" . $p->[0]->{'Value'} . "\n";
    }

    foreach my $e (@choosen_dir_files) {
        print CONFILE $e->[1] . "" . $e->[0]->get() . "\n";
    }
    #####Params
    foreach my $par ( keys(%paramsdefault) ) {
        if(!($par=~m/\(/g)){
        print CONFILE "$par=" . $paramsdefault{$par} . "\n";
    }
    }
    print CONFILE "ANNOTEFILETYPE=" . $Annot . "\n";
    print CONFILE "KASPFOR=" . $KASPpt . "\n";
    print CONFILE "SNPDATABASETYPE=" . $SNPFILETYPE . "\n";
    print CONFILE "definition(unit_size,min_repeats):\t".$paramsdefault{"definition(unit_size,min_repeats):"}."\n";
    print CONFILE  "interruptions(max_difference_between_2_SSRs):\t".$paramsdefault{"interruptions(max_difference_between_2_SSRs):"}."\n";
    close CONFILE;
}

#### Get files paths needed for Spoon processes
sub get_file {
    $lastD = standards::getlastD();
    my @types =
      ( [ "TEXT files", [qw/.txt .prims .INV .vcf .map/] ], [ "All files", '*' ], );
    my $filepath =
      $mw->getOpenFile( -initialdir => $lastD, -filetypes => \@types )
      or return ();
    my $entry = $_[0];
    $entry->delete( '0.0', 'end' );
    $entry->insert( 0, $filepath );
    $lastD = dirname($filepath);
    standards::setLastD($lastD);
    return ($filepath);
}

#### Get Directories paths needed for Spoon processes
sub getDir {
    $lastD = standards::getlastD();
    my $dir = $mw->chooseDirectory(
        -initialdir => $lastD,
        -title      => 'Choose a folder'
    );
    if ( !defined $dir ) {

    }
    else {
        my $entry = $_[0];
        $entry->delete( '0.0', 'end' );
        $entry->insert( 0, $dir );
        $lastD = $dir;
        standards::setLastD($lastD);
    }
}

############ Spoon Has finished
sub Processfinished {

    my ($mw) = @_;
    my $answer = $mw->Dialog(
        -title => 'Spoon Finished :)',
        -text  => 'Spoon has finsihed tasting at results are stored in : '
          . $OUTDIR,
        -default_button => 'ok',
        -buttons        => ['ok'],
    )->Show();
    if ( $answer eq 'ok' ) {
    }
}

##############

sub runspoon {
    ECHO("Starting new process");
    my %config    = user_config::readconfigfile( $OUTDIR . "/config.info" );
    my $outputdir = $config{"OUTDIR"} . $config{PLATDIR};
######################	Create Information files from Seq(s) and user configurations
    #temp
    user_config::createinfofiles( \%config );

######################	Start selected processes
######################	If In silico PCR has been chosen
    if ( $config{"DOINSILICO"} eq "YES" ) {
      ECHO("In silico PCR");
    my $dir = $config{FASTADIR};  
    my @fafiles = user_config::get_fasta_in_dir($dir,\%config);
    my $missmatch=$config{"PMISS"};
    my $primsfile=$config{"PRIMERSFILE"};
    my %primers=MainSpoon::get_primers_from_file(\%config);
    ########### Creatting new primers file with reverse comp primers
    my $ptempfile=$config{"OUTDIR"}.$config{PLATDIR}."PTEMP"; 
    MainSpoon::print_rvc_primers_to_ptemp(\%primers,$ptempfile);
    ##########
    my $tempfile=$config{"OUTDIR"}.$config{PLATDIR}."TEMP";
    my $outfile=$config{"OUTDIR"}.$config{PLATDIR}."In_silico_PCR_Results.csv";

    my  %insresult; 
    foreach my $file (@fafiles)
    {
      my $filepath = $dir.$config{PLATDIR}.$file;
        ECHO("Processing $file\n");

         $filepath ="\"$filepath\"";
      system("./bin/Spoon-C.out $filepath \"$ptempfile\" $missmatch > \"$tempfile\"");
        ECHO("Processing $file\n");
      my %newresults ; 
      %newresults = MainSpoon::createresults($tempfile,$outfile,\%config );
      %insresult = MainSpoon::Add_pre_results(\%insresult,\%newresults);
            
    }
     MainSpoon::printinsresult(\%insresult,$outfile,\%config);  
     unlink $tempfile;
     unlink $ptempfile;    





    }
######################	If PCR Statistics has been chosen
    if ( $config{"PCRSTAT"} eq "YES" ) {
        covstatics::getstat( \%config );
        ECHO("In silico PCR coverage analysis");
    }
######################	If in silico amplicons extraction has been chosen
    if ( $config{"EXTRACTAMPS"} eq "YES" ) {
        MainSpoon::extractinsamp( \%config );
        ECHO("retriving in silico PCR amplicons sequences from FASTA file(s)");
    }
######################	Searching for amplicons adjoin or near genes
    if ( $config{"GENESAROUND"} eq "YES" ) {

        ECHO("Searching for PCR amplicons near or adjoin genes");
        my $glocfile =
          $config{"OUTDIR"} . $config{PLATDIR} . "Seq_Genes_Loc.txt";

        #If user providede genbank annotation files
        if ( $config{ANNOFILE} eq "GB" ) {
            genesaround::createglocfilefromgb( \%config );
            $config{ANNOFILE} = $glocfile;
        }

        #if user provided list files
        if ( $config{ANNOFILE} eq "LIST" ) {
            genesaround::createglocfilefromlist( \%config );
            $config{ANNOFILE} = $glocfile;
        }
        genesaround::getgenesaround( \%config );
    }
#################### SEARCH FOR SSR
    if ( $config{"DOSSR"} eq "YES" ) {
         
        ECHO("Searching for SSR");       
        my $infile=$config{"OUTDIR"}.$config{PLATDIR}."In_silico_amplimers_sequence-for-SSR.fasta"; 
        my $insResult=$config{"OUTDIR"}.$config{PLATDIR}."In_silico_PCR_Results.csv";
        MISA::misa($infile,$config{"OUTDIR"}.$config{PLATDIR}."config.info");
        my %MISA=MISA::read_misa($infile.".misa");
        my %insfile=MISA::readinsresult($insResult);
        #WRITE PRIMER MOTIF REPORT
        report::print_primer_motif_report(\%MISA,$config{"OUTDIR"}.$config{PLATDIR}."PRIMER-MOTIF-report.txt"); 
        #WRITE TO FILE
        open(SSRFILE,">".$config{"OUTDIR"}.$config{PLATDIR}."In_silico_PCR_Results_With_SSR.csv");
        foreach my $k(keys(%MISA)){print SSRFILE $insfile{$k}.",".$MISA{$k}."\n"}                
        close SSRFILE;

    }  

##################### KASP ASSAY
    if ( $config{CREATEKASP} eq "YES" ) {

        my $snpResult =
          $config{"OUTDIR"} . $config{PLATDIR} . "SNPs-NearBy.txt";
        my $KASP  = $config{"OUTDIR"} . $config{PLATDIR} . "KASP-primers.csv";
        my $snpDB = $config{"SNPFILE"};
        my $snpDistance = $config{"SNPDIST"};
        my $insResult =
          $config{"OUTDIR"} . $config{PLATDIR} . "In_silico_PCR_Results.csv";
        my $snpdatabasetype = $config{"SNPDATABASETYPE"};
        if ( $config{"KASPFOR"} eq "G" ) {
            $insResult =
                $config{"OUTDIR"}
              . $config{PLATDIR}
              . "In_silico_PCR_near_or_adjoin_genes.csv";
        }

        #Search for SNPs nearby

        KASPassay::select_snps_nearby( $insResult, $snpDB, $snpdatabasetype,
            $snpDistance, $snpResult );
        my $dir = $config{FASTADIR};
        my @fafiles = user_config::get_fasta_in_dir( $dir, \%config );
        foreach my $file (@fafiles) {

            #Create KASP for each
            KASPassay::create_kasp( $dir . $config{PLATDIR} . $file,
                $snpDB, $snpResult, $KASP );
        }

    }

#####################	Comparing in silico amplicons to in vitro amplicons

    if ( $config{"PCRALIGN"} eq "YES" ) {
        ECHO(
"Comparing in silico and in vitro PCR amplicons according to MW and Pb length"
        );
        my @matches = insinvcompare::compare_ins_inv( \%config );
        insinvcompare::print_ins_inv_Amps( \%config, \@matches );

        #create circos conf. for ins-inv comparison
        if ( $config{"PCRCIRCOS"} eq "YES" ) {
            ECHO("Creating Circos Config. for In silico - In vitro Comparison");
            ############ Circos configuration for align in-ins comparison
            mkdir $outputdir . "CircosAlign";
            insinvcompare::create_def_circosalign( \%config, \@matches,
                $outputdir . "CircosAlign" );
            insinvcompare::print_bands_highlights( \%config, \@matches,
                $outputdir . "CircosAlign" );
            insinvcompare::print_links_file( \%config, \@matches,
                $outputdir . "CircosAlign" );
            my $genes = 0;
            if ( $config{"AlIGNINVITROTO"} =~ m/G/g ) { $genes = 1; }
            templates::createcircoalignconf(
                $outputdir . "CircosAlign" . $config{PLATDIR}, $genes );

            if ( $genes == 1 ) {
                insinvcompare::print_genes_file_circos_align( \%config,
                    \@matches, $outputdir . "CircosAlign" . $config{PLATDIR} );
            }
        }

    }
########################### Create circos conf for in silico Stat.
    if ( $config{"PCRCIRCOS"} eq "YES" ) {
        ECHO("Creating Circos Config. for In silico coverage analysis");
        my %covarea    = MainSpoon::readcoveredareas( \%config );
        my @colors     = MainSpoon::colors();
        my @parray     = sort { lc($a) cmp lc($b) } keys(%covarea);
        my %pn         = circosconf::get_prims_n_for_inscircos( \%config );
        my $coutputdir = $config{"OUTDIR"} . $config{PLATDIR} . "Circos";
        ######## These are statistics
        my %anchorprims = covstatics::get_anchor_prims( \%covarea );
        covstatics::print_anchor_pfile( \%anchorprims, \%config );
        ############ make dir for circos config
        mkdir $coutputdir;
        circosconf::create_PsetBand_file( \%pn, \%config, $coutputdir );
        circosconf::print_link_Pset_hit( \@parray, \%covarea, \%pn, $coutputdir,
            \@colors, \%config );
        my @stats = circosconf::get_cov_stat_for_circos( \%covarea, \@parray );

        #primer coverage statistics
        my %pcstatistics = %{ $stats[0] };

        #primer set coverage statistics
        my %pstatistics = %{ $stats[1] };

        # Seq areacoverage statistics
        my %cstatistics = %{ $stats[2] };

        # Total area covered by all p. set
        my $tatolcover = $stats[3];
        circosconf::print_circos_statics( $coutputdir, \%pcstatistics,
            \%pstatistics, \%cstatistics, $tatolcover, \%config, \%pn,
            \%anchorprims );
        my %areas = covstatics::get_all_covered_areas( \%covarea, \@parray );
        ########### get max chrom for circos
        my $maxchrom = covstatics::get_max_Seq_length( \%areas );
        circosconf::print_def_statcircos( \%areas, \%pn, $coutputdir,
            \%config );
        ########### Genes file
        circosconf::print_genes_statcircos( \%config, $coutputdir, \%areas );
        ######### Hit links
        circosconf::print_hitlinks_statcircos( \@colors, \%config, $coutputdir,
            \%pn, \%areas );
        templates::createcircosconf( $coutputdir . $config{PLATDIR},
            $maxchrom );

    }

    if ( $config{"MAPCOMPARE"} eq "YES" ) {

        ECHO("Comparing linkage map and in silico map");

        my $dir   = $config{"MAPFOLDER"};
        my @files = comparemaps::get_maps_in_dir($dir);
        my $insfile =
          $config{"OUTDIR"} . $config{PLATDIR} . "In_silico_PCR_Results.csv";
        my %ins_results = covstatics::readinsresult($insfile);

###### Read maps
        my %lginfo;
        my %p_map;
        my $filepath = $config{"OUTDIR"} . $config{PLATDIR};
        my @out_array =
          comparemaps::read_maps( \@files, $dir . $config{PLATDIR} );
        %p_map  = %{ $out_array[0] };
        %lginfo = %{ $out_array[1] };
##### get Sq infos and key codes
        my $keycodefile = $config{"OUTDIR"} . $config{PLATDIR} . "keycode.info";
        my $seqinfofile = $config{"OUTDIR"} . $config{PLATDIR} . "seq.info";
        my %seqinfos    = user_config::readseqinfo($seqinfofile);
        my %seqkeys     = user_config::readseqkey($keycodefile);
        my %covarea     = MainSpoon::readcoveredareas( \%config );
        my @parray      = sort { lc($a) cmp lc($b) } keys(%covarea);
        my %areas    = covstatics::get_all_covered_areas( \%covarea, \@parray );
        my $maxchrom = covstatics::get_max_Seq_length( \%areas );
        my %pn       = circosconf::get_prims_n_for_inscircos( \%config );
        my $OutDir =
            $config{"OUTDIR"}
          . $config{PLATDIR}
          . "CircosCompare"
          . $config{PLATDIR};
        my @outdir =
          comparemaps::print_links_compare_file( \%ins_results, \%p_map,
            $OutDir, \%seqkeys, \%pn );
        my %chrs_here = %{ $outdir[0] };
        my %lgs_here  = %{ $outdir[1] };
        comparemaps::lg_chr_assign_file( \%lgs_here, \%seqkeys,
            $config{"OUTDIR"} . $config{PLATDIR} );

        if ( $config{"PCRCIRCOS"} eq "YES" ) {

            #Create map Compare Dir
            ECHO("Creating Circos for linkage and in silico maps comparison");
            mkdir $config{"OUTDIR"} . $config{PLATDIR} . "CircosCompare";
            comparemaps::print_def(
                \%chrs_here, \%lgs_here, \%seqkeys,
                \%seqinfos,  \%lginfo,   $OutDir
            );
            my @lgs = keys(%lgs_here);
            templates::Circos_compare_config( \@lgs, $maxchrom, $OutDir );
        }

    }

######################################### Create finished process report
######################################### Create Report Table
    ECHO("Creating Spoon report");
    my $insfile    = $outputdir . "In_silico_PCR_Results.csv";
    my $ingfile    = $outputdir . "In_silico_PCR_near_or_adjoin_genes.csv";
    my $insinvfile = $outputdir . "INS_INV_Amps.txt";
    my $covstatfile = $outputdir . "Coverage_statistical_analysis_output_by_base_pair.csv";
    my $insssr      = $outputdir .  "In_silico_PCR_Results_With_SSR.csv";
    my $allinsbands = 0;
    my $tgenes      = 0;
    my $totalcov    = 0;
    my $totalcovper = 0;
    my $anchc       = 0;
    my @allprimers  = MainSpoon::get_primers_names_from_file( \%config );

    ##If these results existed add to report
    my %ft = ();
    stat($insfile);
    if ( -e _ ) {
        ECHO("Reading in silico FILES");
        my @out = report::readins( $insfile, \%ft, $allinsbands );
        %ft          = %{ $out[0] };
        $allinsbands = $out[1];

    }
    stat($covstatfile);
    if ( -e _ ) {
        my @cout = report::covstat( $covstatfile, \%ft, $totalcov );
        %ft       = %{ $cout[0] };
        $totalcov = $cout[1];
        my @statout = report::covper(
            $outputdir
              . "Coverage_statistical_analysis_output_by_percentage.csv",
            \%ft, $totalcovper
        );
        %ft          = %{ $statout[0] };
        $totalcovper = $statout[1];
        ECHO("Reading in silico coverage FILES");
    }
    stat($insssr);              
    if ( -e _ ) {
        print "Reading SSR FILES\n";                  
        my %ft = report::readSSR($insssr,\%ft);
    }
    stat($ingfile);
    if ( -e _ ) {
        %ft = report::reading( $ingfile, \%ft );
        my @gout = report::get_agene_count_and_anchror_chr( \%ft );
        $tgenes = $gout[0];
        $anchc  = $gout[1];

        ECHO("Reading Genic in silico FILES");
    }

    stat($insinvfile);
    if ( -e _ ) {
        %ft = report::readinvins( $insinvfile, \%ft );
        ECHO("Reading in vitro in silico Comparison  FILES");
    }

################################# print table
    ECHO("Printing report");
    report::print_report_table( \%ft, $outputdir );

######################################### Create Report Text

    open( RTTXT, ">" . $outputdir . "Report_text.txt" );
    print RTTXT "Total number of primers :" . "\t"
      . ( $#allprimers + 1 )
      . "\tprimer(s)\n";
    print RTTXT "Total number of primers with hits :" . "\t" .
      keys(%ft) . "\tprimer(s)\n";
    print RTTXT "Total number of insilico bands :" . "\t"
      . $allinsbands
      . "\t band(s)\n";
    print RTTXT "Total number of genic insilico bands :" . "\t" . $tgenes
      . "\t gene(s)\n";
    print RTTXT "Genome Coverage :" . "\t"
      . $totalcov
      . "bp\t which about $totalcovper% of the total area\n";
    print RTTXT "Primers exists in one chr (anchor) :" . "\t" . $anchc
      . "\tprimer(s)\n";
    close RTTXT;

############################################## END

    ECHO("SPOON has FINISHED");
}

sub ECHO {
    my ($say) = @_;

    tie *STDOUT, ref $ProgText, $ProgText;
    print "$say\n";
    $mw->update;

}

$mw->MainLoop();
