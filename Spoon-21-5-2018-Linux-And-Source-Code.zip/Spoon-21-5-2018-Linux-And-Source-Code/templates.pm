package templates;



sub createcircosconf
{
my($outdir,$maxchrom)=@_;

open(CAFILE,">".$outdir."circos.conf");
print CAFILE 
"karyotype =DEF.txt
###If your chromosomes samller than this please adjust
chromosomes_units = ".($maxchrom/10)."
chromosomes_display_default = yes
chromosomes_scale   = PSET=0.1r
<<include ideogram.conf>>

chromosomes_color   = PSET=White
<links>
<link>
file          = Links.lk
radius        = 0.95r
ribbon           = yes
bezier_radius = 0r
flat             = yes
color         = blue
thickness     = 2
z=100
radius1       = 1r
<rules>
<rule>
condition  = var(id) =~ /(\d+)-(\d+)/
</rule>
</rules>
</link>
</links>
<plots>
<plot>
type = histogram
file = statistics_by_PCoverONTotal.txt
orientation = out
r0   = 1r+350p
r1   = 1r+400p
fill_color = blue
extend_bin = no
</plot>
<plot>
type = histogram
file = statistics_by_PCoverONLength.txt
orientation = out
min  = 0
max  = 100
r0   = 1r+400p;
r1   = 1r+450p;
fill_color = red
extend_bin = no
</plot>
        <plot>
	type  = text
	color = black
	file  = statistics.BANDS
	r0    = 1r+300p
	r1    = 1r+350p
	label_size = 5
	label_font = italic
	show_links     = no
	link_dims      = 0p,2p,6p,2p,5p
	link_thickness = 2p
	link_color     = black
	label_snuggle        = yes
	max_snuggle_distance = 1r
	snuggle_tolerance    = 0.25r
	snuggle_sampling     = 2
	snuggle_refine       = yes
        </plot>

	<plot>
        type             = scatter
	file             = Primers_with_Genes.txt
	fill_color       = red
	stroke_color     = black
	glyph            = circle
	glyph_size       = 10
	max   = 0.013
	min   = 0
        r0    = 1r+280p
	r1    = 1r+300p
	</plot>

        <plot>
 	type  = text
	color =black
	file  = GENESTITLE.txt
	r0    = 1r
	r1    = 1r+300p
	label_size = 5
	label_font = default
	show_links     = yes
	link_dims      = 0p,2p,6p,2p,5p
	link_thickness = 2p
	link_color     = black
	label_snuggle        = yes
	max_snuggle_distance = 1r
	snuggle_tolerance    = 0.25r
	snuggle_sampling     = 2
	snuggle_refine       = yes
	</plot>
</plots>
<highlights>
<highlight>
file       = HITLINKS.txt
r0         = 1r
r1         = 0.95r
</highlight>

</highlights>
<image>
<<include etc/image.conf>>                
</image>
<<include etc/colors_fonts_patterns.conf>> 
<<include etc/housekeeping.conf>> 
";
close CAFILE;


open(IDEOFILE,">".$outdir."ideogram.conf");
print IDEOFILE "
<ideogram>

<spacing>

default = 1u
break   = 0u

axis_break_at_edge = yes
axis_break         = yes
axis_break_style   = 2

<break_style 1>
stroke_color = black
fill_color   = blue
thickness    = 0.25r
stroke_thickness = 2
</break>

<break_style 2>
stroke_color     = black
stroke_thickness = 3
thickness        = 1.5r
</break>

</spacing>

# thickness (px) of chromosome ideogram
thickness        = 40p
stroke_thickness = 2
# ideogram border color
stroke_color     = black
fill             = yes
# the default chromosome color is set here and any value
# defined in the karyotype file overrides it
fill_color       = black

# fractional radius position of chromosome ideogram within image
radius         = 0.6r
show_label     = yes
label_with_tag = yes
label_font     = bold
label_radius   = 1r+550p
label_size     = 15p
label_parallel = yes
label_case     = default

# cytogenetic bands
band_stroke_thickness = 2

# show_bands determines whether the outline of cytogenetic bands
# will be seen
show_bands            = yes
# in order to fill the bands with the color defined in the karyotype
# file you must set fill_bands
fill_bands            = yes

</ideogram>
";
close IDEOFILE;
}


sub createcircoalignconf
{
my($outdir,$genes)=@_;

if($genes==1)
{
$genes="<plots> 
        <plot>
 	type  = text
	color =black
	file  = GENESTITLE.txt
	r0    = 1r
	r1    = 1r+300p
	label_size = 5
	label_font = default
	show_links     = yes
	link_dims      = 0p,2p,6p,2p,5p
	link_thickness = 2p
	link_color     = black
	label_snuggle        = yes
	max_snuggle_distance = 1r
	snuggle_tolerance    = 0.25r
	snuggle_sampling     = 2
	snuggle_refine       = yes
	</plot>
        </plots>";

}


open(CFILE,">".$outdir."circos.conf");
	print CFILE "karyotype =DEF.txt
	chromosomes_units = 10;
	chromosomes_display_default = yes
	<highlights>
	<highlight>
	file       = HIGHLIGHT.txt
	r0         = 1r;
	r1         = dims(ideogram,radius)-40;
	</highlight>
	</highlights>
	<links>
	<link>
	file          = LINKS.txt
	radius        =  0.95r
	</link>
	</links>
	"
	.$genes
	.
	"
	<<include ideogram.conf>>
	<<include ticks.conf>>

	<image>
	<<include etc/image.conf>>                
	</image>
	<<include etc/colors_fonts_patterns.conf>> 
	<<include etc/housekeeping.conf>> 
	";
close CFILE;

open(DFILE,">".$outdir."ideogram.conf");
	print DFILE "
	<ideogram>
	<spacing>
	default = 10u
	break   = 10u
	axis_break_at_edge = yes
	axis_break         = yes
	axis_break_style   = 2
	<break_style 1>
	stroke_color = black
	fill_color   = blue
	thickness    = 0.25r
	stroke_thickness = 2
	</break>
	<break_style 2>
	stroke_color     = black
	stroke_thickness = 3
	thickness        = 1.5r
	</break>
	</spacing>
	# thickness (px) of chromosome ideogram
	thickness        = 40p
	stroke_thickness = 2
	# ideogram border color
	stroke_color     = black
	fill             = no
	# the default chromosome color is set here and any value
	# defined in the karyotype file overrides it
	fill_color       = black
	# fractional radius position of chromosome ideogram within image
	radius         = 0.6r
	show_label     = yes
	label_with_tag = yes
	label_font     = bold
	label_radius   = dims(ideogram,radius)+100p
	label_size     = 15p
	label_parallel = yes
	label_case     = upper
	# cytogenetic bands
	band_stroke_thickness = 2
	# show_bands determines whether the outline of cytogenetic bands
	# will be seen
	show_bands            = no
	# in order to fill the bands with the color defined in the karyotype
	# file you must set fill_bands
	fill_bands            = no
	</ideogram>
	";
close DFILE;

open(TFILE,">".$outdir."ticks.conf");
	print TFILE "
	show_ticks          = yes
	show_tick_labels    = yes
	<ticks>
	radius               = dims(ideogram,radius_outer) + 10p
	multiplier           = 1
	<tick>
	spacing        = 50u
	size           = 5p
	thickness      = 1p
	color          = black
	show_label     = yes
	label_size     = 10p
	label_offset   = 2p
	format         = %d
	</tick>
	</ticks>";
close TFILE;
}


sub Circos_compare_config
{
my($lgs,$maxchrom,$outdir)=@_;
my @lgs=@{$lgs};
open(FILE,">".$outdir."circos.conf");
print FILE
"karyotype =DEF.txt
###If your chromosomes samller than this please adjust
chromosomes_units = ".($maxchrom/10)."
chromosomes_display_default = yes
";

print FILE
"
chromosomes_scale   =".return_lgs_scale(@lgs)."
";

print FILE
"
<<include ideogram.conf>>
chromosomes_color   = PSET=White

<links>
<link>
file          = Links.txt
radius        = 0.95r
ribbon           = yes
flat             = yes
color         = blue
thickness     = 2
</link>
</links>


<plots>
<plot>
 	type  = text
	color =black
	file  = Ptitles.txt
	r0    = 1r
	r1    = 1r+300p
	label_size = 5
	label_font = default
	show_links     = yes
	link_dims      = 0p,2p,6p,2p,5p
	link_thickness = 2p
	link_color     = black
	label_snuggle        = yes
	max_snuggle_distance = 1r
	snuggle_tolerance    = 0.25r
	snuggle_sampling     = 2
	snuggle_refine       = yes
	</plot>
</plots>

<image>
<<include etc/image.conf>>                
</image>
<<include etc/colors_fonts_patterns.conf>> 
<<include etc/housekeeping.conf>> 
";
close FILE; 


open(IDFILE,">".$outdir."ideogram.conf");
print IDFILE
"

<ideogram>

<spacing>

default = 1u
break   = 0u

axis_break_at_edge = yes
axis_break         = yes
axis_break_style   = 2

<break_style 1>
stroke_color = black
fill_color   = blue
thickness    = 0.25r
stroke_thickness = 2
</break>

<break_style 2>
stroke_color     = black
stroke_thickness = 3
thickness        = 1.5r
</break>

</spacing>

# thickness (px) of chromosome ideogram
thickness        = 40p
stroke_thickness = 2
# ideogram border color
stroke_color     = black
fill             = yes
# the default chromosome color is set here and any value
# defined in the karyotype file overrides it
fill_color       = black

# fractional radius position of chromosome ideogram within image
radius         = 0.8r
show_label     = yes
label_with_tag = yes
label_font     = bold
label_radius   = 1r+100p
label_size     = 30p
label_parallel = yes
label_case     = default

# cytogenetic bands
band_stroke_thickness = 2

# show_bands determines whether the outline of cytogenetic bands
# will be seen
show_bands            = yes
# in order to fill the bands with the color defined in the karyotype
# file you must set fill_bands
fill_bands            = yes

</ideogram>
";

close IDFILE;




}

sub return_lgs_scale
{
my(@lgs)=@_;
my $divide  =sprintf("%.2f",(0.5/$#lgs));
my @line;
foreach my $lg(@lgs)
{
 push (@line,"$lg\=".$divide."rn");
}
return join(",",@line);
}
1;
