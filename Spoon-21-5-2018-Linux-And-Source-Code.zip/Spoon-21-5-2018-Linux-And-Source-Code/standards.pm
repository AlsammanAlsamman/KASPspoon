package standards;
my @labelsText=( 
             '___________________In silico PCR_________________________',
             'Primer Mismatch',
	     'Primer Pair Mismatch',
             '3\' Missmatch after Nu. #',                
	     'Min. Amplicon length',
             'Max. Amplicon length',
             '_______________Amplicons Seq. Extarction__________________',
             '# Nu. bp Upstearm',
             '# Nu. bp Downstream',
             '______________Primer Set Genome Coverage______________________',
	     'Max. Gap (# Nu.) bewteen two Amp. Areas',
             '________Distance for gene(s) coveage and KASP Assay__________',
             'Gene Distance',
             'SNP Distance',
             '____________In vitro and In slico PCR comaprison____________',
             'Max. Inv-Ins-amp Mis.',
             'Compare In vitro  Results to',
 	     '____________________Circos Main Order_____________________',
             'and Chr(s) by',
             'Chr(s) key',
             '_____Simple Sequence Repeats Detection (MISA)________',
             'Unit size-Min. Repeats',
             'Max. Distance between two SSR'


              );
my @TextBoxs=(
		["PMISS=",0],
		["CMISS=",0],
		["P3PRIMEMISSN=",5],
		["MINBL=",50],
		["MAXBL=",1500],
		"",
		["UPSTEAREM=",1000],
		["DOWNSTREAM=",1000],
		"",
		["MAXGAPBAMP=",50],
		"",
		["GENEDIST=",1000],
		["SNPDIST=",0],
		"",
		["INV-INS-Miss=",10],
                ["AlIGNINVITROTO=",""],
		"",
		["ORDERACCORDINGTO=","GI"],
		["CHRKEY=","Chr"],
                "",
                ["definition(unit_size,min_repeats):","1-10 2-6 3-5 4-5 5-5 6-5"],
                ["interruptions(max_difference_between_2_SSRs):","100"]  
                 );

my @win1chick_Button_text=(
    ["In silico PCR","DOINSILICO="],
    ["In silico amplicons sequences extraction","EXTRACTAMPS="],
    ["Genic in silico amplicons reporting using annotation(s)","GENESAROUND="],
    ["Check for Simple Sequence Repeats using MISA","DOSSR="],
    ["In silico PCR coverage statistics","PCRSTAT="],
    ["Linkage and in silico maps comparison","MAPCOMPARE="],
    ["Amplicons comparison between in vitro and in silico PCR ","PCRALIGN="],
    ["Circos configuration","PCRCIRCOS="],
    ["Create KASP primers","CREATEKASP="]);

my @win1_file_dir_label=(
    ["Output Directory","OUTDIR="],
    ["Primers File","PRIMERSFILE="],
    ["Sequence(s) Directory","FASTADIR="],
    ["Area to Cover (PCR-Walking) File/All","PCOVAREA="],
    ["In vitro PCR File","INVITROPCR="],
    ["Annotation(s) Directory","GENBANKDIR="],
    ["Genetic Linkage Map(s) Directory","MAPFOLDER="],    
    ["SNP Info File","SNPFILE="]
);
sub paramlabelstext{return @labelsText;}
sub paramtextboxdefault{return @TextBoxs;}
sub win1_chick_buttons_text{return @win1chick_Button_text;}
sub win1_file_dir_label{return  @win1_file_dir_label;}
sub win1whatentery
{
  my($t)=@_;
  my $e;
  if($t=~/Dir/){$e="Directory"}
  if($t=~/File/){$e="File"} 
  return $e;
}


#### Set the last files paths
sub setLastD {
    my($lastD);
    open( DFILE, ">Config/lastD.txt" );
    print DFILE $lastD . "\n";
    close DFILE;
}
#### Get the last files paths

sub getlastD { 
    my $lastD;
    open( DFILE, "<Config/lastD.txt" );
    while (<DFILE>) { chomp(); $lastD = $_ }
    close DFILE;
    return;
}


1;
