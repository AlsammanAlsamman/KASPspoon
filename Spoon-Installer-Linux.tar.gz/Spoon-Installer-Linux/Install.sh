echo "Creating Spoon C searcher tool"
gcc  bin/INSILICO.c -o bin/c-Xsearch.out
