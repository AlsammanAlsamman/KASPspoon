package insinvcompare;
use MainSpoon;

sub print_links_file
{
my($config,$matches,$outputdir)=@_;
my @matches=@{$matches};
my %config=%{$config};

my @colors=MainSpoon::colors();
my %prims = insinvcompare::get_prims_matches_n(@matches);
open(LINKFILE,">".$outputdir.$config{PLATDIR}."LINKS.txt");
foreach my $m (@matches)
{
 my $insamp=$m->[0];
 my $amp=$m->[1];
 my $pbin=$insamp->{"pnam"};
 my $acc=$insamp->{"seqnam"};
 print LINKFILE "INV-$pbin\t".$amp->{"mw"}."\t".($amp->{"mw"}+50).
       "\t"."INS-$pbin\t".$insamp->{"aml"}."\t".($insamp->{"aml"}+50).
       "\tcolor=".$colors[$prims{$pbin}]."\n";
}
close LINKFILE;
}

sub compare_ins_inv
{
my($config)=@_;
my %config=%{$config};
my %pamps;
###If user choose to compare for inslico amps with genes
if($config{"AlIGNINVITROTO"}=~m/G/g)
{

%pamps = MainSpoon::getbypbyaccbyg(\%config);
}
else{
%pamps = MainSpoon::getbypbyacc(\%config);
}

my $maxamp=$config{"MINBL"};
my %pbinary=MainSpoon::readBinaryamps(\%config);
my @colors=MainSpoon::colors();
my $miss=$config{INVINSMiss};
my @matches;
foreach my $pbin(keys(%pbinary))
{   
        foreach my $acc (keys(%{$pamps{$pbin}}))
	{
		foreach my $insamp (@{$pamps{$pbin}{$acc}})
		{ 

                             foreach my $amp (@{$pbinary{$pbin}})
                             {
                                    my $sub=$amp->{"mw"}-$insamp->{"aml"} ;
                                       $sub=~s/-//g;
				    if($sub<=$miss)
				     {
                                       push(@matches,[$insamp,$amp])            
				     }   
                             } 

		}
	}
}
return @matches;
}

sub print_genes_file_circos_align
{
	my($config,$matches,$outputdir)=@_;
	my @matches=@{$matches};
	my %config=%{$config};
open(GFILE,">".$outputdir."GENESTITLE.txt");
	foreach my $m (@matches)
	{
	 my $insamp=$m->[0];
	 my $pbin=$insamp->{"pnam"};
	 my $gene=$insamp->{"gene"};
	 if($insamp->{"gene"} ne "")
	    { 
	     print GFILE "INS-$pbin\t".$insamp->{"aml"}."\t".($insamp->{"aml"}+20)."\t".$insamp->{"gene"}."\n";  
	    }

	}
close GFILE;
}

sub print_ins_inv_Amps
{
my($config,$matches)=@_;
my @matches=@{$matches};
my %config=%{$config};
my $outdir=$config{"OUTDIR"}.$config{PLATDIR};
open(DINFILE,">".$outdir."INS_INV_Amps.txt");
foreach my $m (@matches)
{
 my $insamp=$m->[0];
 my $amp=$m->[1];
 my $pbin=$insamp->{"pnam"};
 my $acc=$insamp->{"seqnam"};
 print DINFILE "$pbin\t".$amp->{"mw"}."\t"."\t$acc\t".$insamp->{"aml"}."\t".$insamp->{"gene"}."\n"; 
}
close DINFILE;
}

sub print_bands_highlights
{
my($config,$matches,$outputdir)=@_;
my @matches=@{$matches};
my %config=%{$config};
my $maxamp=$config{"MAXBL"};
my %prims = insinvcompare::get_prims_matches_n(@matches);
my %pamps;
	if($config{"AlIGNINVITROTO"}=~m/G/g)
	{
        
	%pamps = MainSpoon::getbypbyaccbyg(\%config);
	}
	else{
	%pamps = MainSpoon::getbypbyacc(\%config);
	}
my %pbinary = MainSpoon::readBinaryamps(\%config);
my $hfile =$outputdir.$config{PLATDIR}."HIGHLIGHT.txt";
#clear HFile
open(HFILE,">".$hfile);
close HFILE;
foreach my $p(keys(%prims))
{
 insinvcompare::printINStohighligth($p,\%pamps,$hfile);
 insinvcompare::printINVtohighligth($p,\%pbinary,$hfile);
}

}

sub create_def_circosalign
{
my($config,$matches,$outputdir)=@_;
my @matches=@{$matches};
my %config=%{$config};
my $maxamp=$config{"MAXBL"};
my @colors=MainSpoon::colors();
my %prims = insinvcompare::get_prims_matches_n(@matches);
open(DEFFILE,">".$outputdir.$config{PLATDIR}."DEF.txt");
foreach my $p(keys(%prims))
{
	print  DEFFILE "chr\t-\tINS-$p\tINS-$p\t0\t$maxamp\t".$colors[$prims{$p}]."\n"; 
	print  DEFFILE "chr\t-\tINV-$p\tINV-$p\t0\t$maxamp\t".$colors[$prims{$p}]."\n"; 
}
close DEFFILE;
}

sub get_prims_matches_n
{
 my(@matches)=@_;
 my %prims;
 my $n=1;
 foreach my $m(@matches)
 {
            if(!$prims{$m->[0]->{"pnam"}})
              {
                $prims{$m->[0]->{"pnam"}}=$n;
                $n++;  
              }
             
 }
 return %prims;
}

sub printINStohighligth
{
        my($p,$pamps,$hfile)=@_;
        my %pamps=%{$pamps};
        open(HFILE,">>".$hfile);

        foreach my $acc (keys(%{$pamps{$p}}))
	{
		foreach my $insamp (@{$pamps{$p}{$acc}})
		{ 
                     print HFILE "INS-$p\t".$insamp->{"aml"}."\t".($insamp->{"aml"}+50)."\t"."fill_color=black"."\n";                         
                }
	}
      close HFILE;

}

sub printINVtohighligth
{
        my($p,$pbinary ,$hfile)=@_;
        my %pbinary =%{$pbinary};
        open(HFILE,">>".$hfile);
        
        foreach my $amp (@{$pbinary{$p}})
	{
           print  HFILE "INV-$p\t".$amp->{"mw"}."\t".($amp->{"mw"}+50)."\t"."fill_color=black"."\n"; 		
	}
      close HFILE;

}






1;
