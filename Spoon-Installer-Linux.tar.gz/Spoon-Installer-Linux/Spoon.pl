#!/usr/bin/perl;
# Author: Alsamman M. Alsamman
# Program name: Spoon
###_______________________________________________________________________________
###
### Program name: Spoon
### Author:       Alsamman M. Alsamman
### Release date: 7/28/17 (version 1.0)
###
###_______________________________________________________________________________
###
## _______________________________________________________________________________
##
## DESCRIPTION: Tool in vitro and in silico PCR analysis for :
##                      (1) Primer selectivity
##                      (2) Fine mapping analysis 
##                      (3) Gene discovery
## _______________________________________________________________________________

######### 4 Process can be run
#       1 - In silico PCR analysis
#       2 - Extract in silico amplicon from ref. seq.
#       3 - Perform in silico PCR statistics
#       4 - Compare in silico Results to in vitro results 


########## Needed Modules
use warnings;
use strict;
use Tk;
use LWP::UserAgent;
use File::Path qw(make_path remove_tree);
use Tk::Dialog;
use File::Basename;
use Data::Dumper;
use Config;
########## Spoon Modules
use MainSpoon;
use genesaround;
use user_config;
use covstatics;
use extractamps;
use insinvcompare;
use templates;
use circosconf;
use report;
##########
my %config;
my $lastD;
##########
#create Cofig Folder if not exists 

mkdir "Config";

####### GUI

####### List of Checkboxes and thier defualt values 
my @TEXTBOXLIST;
my $DOINSILICO  = "NO";
my $EXTRACTAMPS = "NO";
my $PCRSTAT     = "NO";
my $GENESAROUND = "NO";
my $PCRALIGN    = "NO";
my $PCRCIRCOS   = "NO";
my $CREATEDIR   = "NO";
my $ALIGNV      = "INS";
my $Annot       = "GB";

####### widgets positions

my $getdirposx = 190;
my $parposx    = 160;
my $parposy    = 280;
my $parposlbx  = 15;
my $parposlby  = 50;
my $pnu        = 0;
my $pnu2       = 0;
my $parposy2   = 280;
my $parposx2   = 400;
my $parposlbx2 = 250;


####### Main Windows
my $mw = MainWindow->new( -width => '500', -relief => 'flat', -height => '600' );
$mw->resizable( 0, 0 );


### MENU
#$mw->configure(-menu => my $menubar = $mw->Menu);
#$menubar->add('command', -label => 'About',-command => \&ABOUTD);
                                                                 
###### Widgets
my $var1 = $mw->Checkbutton(
    -variable => \$DOINSILICO,
    -onvalue  => 'YES',
    -offvalue => 'NO',
    -text     => 'In silico PCR'
)->place( -x => 10, -y => 10 );
my $var2 = $mw->Checkbutton(
    -variable => \$EXTRACTAMPS,
    -onvalue  => 'YES',
    -offvalue => 'NO',
    -text     => 'In silico amplicons sequences extraction'
)->place( -x => 10, -y => 30 );
my $var30 = $mw->Checkbutton(
    -variable => \$GENESAROUND,
    -onvalue  => 'YES',
    -offvalue => 'NO',
    -text     => 'Genic in silico amplicons reporting using annotation(s)'
)->place( -x => 10, -y => 50 );

#OPTIONS
my $GB =
  $mw->Radiobutton( -text => 'GenBank', -value => "GB", -variable => \$Annot )
  ->place( -x => 300, -y => 50 );
my $LIST =
  $mw->Radiobutton( -text => 'List', -value => "LIST", -variable => \$Annot )
  ->place( -x => 400, -y => 50 );

my $var4 = $mw->Checkbutton(
    -variable => \$PCRSTAT,
    -onvalue  => 'YES',
    -offvalue => 'NO',
    -text     => 'In silico PCR coverage statistics',
)->place( -x => 10, -y => 70 );
my $var5 = $mw->Checkbutton(
    -variable => \$PCRALIGN,
    -onvalue  => 'YES',
    -offvalue => 'NO',
    -text     => 'Amplicons comparison between in vitro and in silico PCR '
)->place( -x => 10, -y => 90 );
my $var6 = $mw->Checkbutton(
    -variable => \$PCRCIRCOS,
    -onvalue  => 'YES',
    -offvalue => 'NO',
    -text     => 'Circos configuration',
)->place( -x => 10, -y => 110 );



my $var1000 = $mw->Label(
    -pady    => '1',
    -relief  => 'flat',
    -padx    => '1',
    -state   => 'normal',
    -justify => 'center',
    -text    => 'Output Directory',
)->place( -x => 10, -y => 130 );



my $var8 = $mw->Label(
    -pady    => '1',
    -relief  => 'flat',
    -padx    => '1',
    -state   => 'normal',
    -justify => 'center',
    -text    => 'Primers file',
)->place( -x => 13, -y => 156 );

my $var9 = $mw->Entry(
    -width   => '40',
    -relief  => 'sunken',
    -state   => 'normal',
    -justify => 'left',
    -text    => 'Click to select file',
)->place( -x => $getdirposx, -y => 160 );
$var9->bind( "<Button-1>", [ \&get_file, $var9 ] );
push( @TEXTBOXLIST, [ $var9, "PRIMERSFILE=" ] );

my $var10 = $mw->Entry(
    -width   => '40',
    -relief  => 'sunken',
    -state   => 'normal',
    -justify => 'left',
    -text    => 'Click to select Dir.',
)->place( -x => $getdirposx, -y => 185 );
$var10->bind( "<Button-1>", [ \&getDir, $var10 ] );
push( @TEXTBOXLIST, [ $var10, "FASTADIR=" ] );

my $var11 = $mw->Label(
    -pady    => '1',
    -relief  => 'flat',
    -padx    => '1',
    -state   => 'normal',
    -justify => 'center',
    -text    => 'Sequence(s) directory',
)->place( -x => 14, -y => 185 );
my $var12 = $mw->Entry(
    -width   => '40',
    -relief  => 'sunken',
    -state   => 'normal',
    -justify => 'left',
    -text    => 'Click to select Dir.',
)->place( -x => $getdirposx, -y => 210 );
$var12->bind( "<Button-1>", [ \&getDir, $var12 ] );
push( @TEXTBOXLIST, [ $var12, "GENBANKDIR=" ] );
my $var13 = $mw->Label(
    -pady    => '1',
    -relief  => 'flat',
    -padx    => '1',
    -state   => 'normal',
    -justify => 'center',
    -text    => 'Annotation(s) direcory',
)->place( -x => 14, -y => 210 );
my $var14 = $mw->Entry(
    -width   => '40',
    -relief  => 'sunken',
    -state   => 'normal',
    -justify => 'left',
    -text    => 'Click to select file',
)->place( -x => $getdirposx, -y => 237 );
push( @TEXTBOXLIST, [ $var14, "INVITROPCR=" ] );


#####Previous Folder

my $prev = $mw->Entry(
    -width   => '40',
    -relief  => 'sunken',
    -state   => 'normal',
    -justify => 'left',
    -text    => 'Click to select Dir.',
)->place( -x => 190, -y => 130 );
$prev->bind( "<Button-1>", [ \&getDir, $prev ] );
push( @TEXTBOXLIST, [ $prev, "OUTDIR=" ] );

#######


my $var16 = $mw->Label(
    -pady    => '1',
    -relief  => 'flat',
    -padx    => '1',
    -state   => 'normal',
    -justify => 'center',
    -text    => 'In vitro PCR file',
)->place( -x => 15, -y => 241 );

$var14->bind( "<Button-1>", [ \&get_file, $var14 ] );

my $PMISSTXT = $mw->Entry(
    -width   => '10',
    -relief  => 'sunken',
    -state   => 'normal',
    -justify => 'left',
    -text    => '0',
)->place( -x => $parposx, -y => ( $parposy + $pnu * 25 ) );
push( @TEXTBOXLIST, [ $PMISSTXT, "PMISS=" ] );
my $PMISSlb = $mw->Label(
    -pady    => '1',
    -relief  => 'flat',
    -padx    => '1',
    -state   => 'normal',
    -justify => 'center',
    -text    => 'Primer mismatch',
)->place( -x => $parposlbx, -y => ( $parposy + $pnu++ * 25 ) );

my $CMISSTXT = $mw->Entry(
    -width   => '10',
    -relief  => 'sunken',
    -state   => 'normal',
    -justify => 'left',
    -text    => '0',
)->place( -x => $parposx, -y => ( $parposy + $pnu * 25 ) );
push( @TEXTBOXLIST, [ $CMISSTXT, "CMISS=" ] );
my $CMISSlb = $mw->Label(
    -pady    => '1',
    -relief  => 'flat',
    -padx    => '1',
    -state   => 'normal',
    -justify => 'center',
    -text    => 'Primer pair mismatch',
)->place( -x => $parposlbx, -y => ( $parposy + $pnu++ * 25 ) );

my $MINBLTXT = $mw->Entry(
    -width   => '10',
    -relief  => 'sunken',
    -state   => 'normal',
    -justify => 'left',
    -text    => '50',
)->place( -x => $parposx, -y => ( $parposy + $pnu * 25 ) );
push( @TEXTBOXLIST, [ $MINBLTXT, "MINBL=" ] );
my $MINBLlb = $mw->Label(
    -pady    => '1',
    -relief  => 'flat',
    -padx    => '1',
    -state   => 'normal',
    -justify => 'center',
    -text    => 'Min. amplicon length',
)->place( -x => $parposlbx, -y => ( $parposy + $pnu++ * 25 ) );

my $MAXBLTXT = $mw->Entry(
    -width   => '10',
    -relief  => 'sunken',
    -state   => 'normal',
    -justify => 'left',
    -text    => '1500',
)->place( -x => $parposx, -y => ( $parposy + $pnu * 25 ) );
push( @TEXTBOXLIST, [ $MAXBLTXT, "MAXBL=" ] );
my $MAXBLlb = $mw->Label(
    -pady    => '1',
    -relief  => 'flat',
    -padx    => '1',
    -state   => 'normal',
    -justify => 'center',
    -text    => 'Max. amplicon length',
)->place( -x => $parposlbx, -y => ( $parposy + $pnu++ * 25 ) );

my $PCOVAREATXT = $mw->Entry(
    -width   => '10',
    -relief  => 'sunken',
    -state   => 'normal',
    -justify => 'left',
    -text    => 'All/click',
)->place( -x => $parposx, -y => ( $parposy + $pnu * 25 ) );
push( @TEXTBOXLIST, [ $PCOVAREATXT, "PCOVAREA=" ] );
$PCOVAREATXT->bind( "<Button-1>", [ \&get_file, $PCOVAREATXT ] );

my $PCOVAREAlb = $mw->Label(
    -pady    => '1',
    -relief  => 'flat',
    -padx    => '1',
    -state   => 'normal',
    -justify => 'center',
    -text    => 'Covered area(s)/Select',
)->place( -x => $parposlbx, -y => ( $parposy + $pnu++ * 25 ) );

my $GENEDISTTXT = $mw->Entry(
    -width   => '10',
    -relief  => 'sunken',
    -state   => 'normal',
    -justify => 'left',
    -text    => '1000',
)->place( -x => $parposx, -y => ( $parposy + $pnu * 25 ) );
push( @TEXTBOXLIST, [ $GENEDISTTXT, "GENEDIST=" ] );
my $GENEDISTlb = $mw->Label(
    -pady    => '1',
    -relief  => 'flat',
    -padx    => '1',
    -state   => 'normal',
    -justify => 'center',
    -text    => 'Gene distance',
)->place( -x => $parposlbx, -y => ( $parposy + $pnu++ * 25 ) );

my $MAXGAPBAMPTXT = $mw->Entry(
    -width   => '10',
    -relief  => 'sunken',
    -state   => 'normal',
    -justify => 'left',
    -text    => '100',
)->place( -x => $parposx, -y => ( $parposy + $pnu * 25 ) );
push( @TEXTBOXLIST, [ $MAXGAPBAMPTXT, "MAXGAPBAMP=" ] );

my $MAXGAPBAMPlb = $mw->Label(
    -pady    => '1',
    -relief  => 'flat',
    -padx    => '1',
    -state   => 'normal',
    -justify => 'center',
    -text    => 'Max. coverage gap',
)->place( -x => $parposlbx, -y => ( $parposy + $pnu++ * 25 ) );

my $UPSTEAREMTXT = $mw->Entry(
    -width   => '10',
    -relief  => 'sunken',
    -state   => 'normal',
    -justify => 'left',
    -text    => '1000',
)->place( -x => $parposx2, -y => ( $parposy2 + $pnu2 * 25 ) );
push( @TEXTBOXLIST, [ $UPSTEAREMTXT, "UPSTEAREM=" ] );

my $UPSTEAREMlb = $mw->Label(
    -pady    => '1',
    -relief  => 'flat',
    -padx    => '1',
    -state   => 'normal',
    -justify => 'center',
    -text    => 'Extract # bp upstearm',
)->place( -x => $parposlbx2, -y => ( $parposy2 + $pnu2++ * 25 ) );

my $DOWNSTREAMTXT = $mw->Entry(
    -width   => '10',
    -relief  => 'sunken',
    -state   => 'normal',
    -justify => 'left',
    -text    => '1000',
)->place( -x => $parposx2, -y => ( $parposy2 + $pnu2 * 25 ) );
push( @TEXTBOXLIST, [ $DOWNSTREAMTXT, "DOWNSTREAM=" ] );
my $DOWNSTREAMlb = $mw->Label(
    -pady    => '1',
    -relief  => 'flat',
    -padx    => '1',
    -state   => 'normal',
    -justify => 'center',
    -text    => 'Extract # bp downstream',
)->place( -x => $parposlbx2, -y => ( $parposy2 + $pnu2++ * 25 ) );

my $INVINSMissTXT = $mw->Entry(
    -width   => '10',
    -relief  => 'sunken',
    -state   => 'normal',
    -justify => 'left',
    -text    => '10',
)->place( -x => $parposx2, -y => ( $parposy2 + $pnu2 * 25 ) );
push( @TEXTBOXLIST, [ $INVINSMissTXT, "INV-INS-Miss=" ] );
my $INVINSMisslb = $mw->Label(
    -pady    => '1',
    -relief  => 'flat',
    -padx    => '1',
    -state   => 'normal',
    -justify => 'center',
    -text    => 'Max. Inv-Ins-amp Mis.',
)->place( -x => $parposlbx2, -y => ( $parposy2 + $pnu2++ * 25 ) );

my $AlIGNINVITROTOlb = $mw->Label(
    -pady    => '1',
    -relief  => 'flat',
    -padx    => '1',
    -state   => 'normal',
    -justify => 'center',
    -text    => 'Compare in vitro to',
)->place( -x => $parposlbx2, -y => ( $parposy2 + $pnu2++ * 25 ) );

$pnu2--;
my $AlIGNINVITROTOlb1 =
  $mw->Radiobutton( -text => 'INS', -value => "INS", -variable => \$ALIGNV )
  ->place( -x => $parposlbx2 + 200, -y => ( $parposy2 + $pnu2 * 25 ) );
my $AlIGNINVITROTOlb2 = $mw->Radiobutton(
    -text     => 'INS-G',
    -value    => "INS-G",
    -variable => \$ALIGNV
)->place( -x => $parposlbx2 + 140, -y => ( $parposy2 + $pnu2 * 25 ) );

$pnu2++;
my $ORDERACCORDINGTOTXT = $mw->Entry(
    -width   => '10',
    -relief  => 'sunken',
    -state   => 'normal',
    -justify => 'left',
    -text    => 'GI',
)->place( -x => $parposx2, -y => ( $parposy2 + $pnu2 * 25 ) );

push( @TEXTBOXLIST, [ $ORDERACCORDINGTOTXT, "ORDERACCORDINGTO=" ] );
my $ORDERACCORDINGTOlb = $mw->Label(
    -pady    => '1',
    -relief  => 'flat',
    -padx    => '1',
    -state   => 'normal',
    -justify => 'center',
    -text    => 'Order Chr(s) by',
)->place( -x => $parposlbx2, -y => ( $parposy2 + $pnu2++ * 25 ) );

my $CHRKEYTXT = $mw->Entry(
    -width   => '10',
    -relief  => 'sunken',
    -state   => 'normal',
    -justify => 'left',
    -text    => 'Chr',
)->place( -x => $parposx2, -y => ( $parposy2 + $pnu2 * 25 ) );
push( @TEXTBOXLIST, [ $CHRKEYTXT, "CHRKEY=" ] );
my $CHRKEYlb = $mw->Label(
    -pady    => '1',
    -relief  => 'flat',
    -padx    => '1',
    -state   => 'normal',
    -justify => 'center',
    -text    => 'Chr(s) key',
)->place( -x => $parposlbx2, -y => ( $parposy2 + $pnu2++ * 25 ) );
$mw->Button( -text => 'Go Taste', -command => \&GOGO )
  ->place( -x => 230, -y => 460 );

### Progress Text Box

my $ProgText =
  $mw->Text( -takefocus => 1, -relief => 'flat', -width => '70', -height => 5 )
  ->place( -x => 0, -y => 500 );



#"
#### Set the last files paths
sub setLastD {
    open( DFILE, ">Config/lastD.txt" );
    print DFILE $lastD . "\n";
    close DFILE;
}
#### Get the last files paths

sub getlastD {
    open( DFILE, "Config/lastD.txt" );
    while (<DFILE>) { chomp(); $lastD = $_ }
    close DFILE;
}



#### Get files paths needed for Spoon processes
sub get_file {
    getlastD();
    my @types =
      ( [ "TEXT files", [qw/.txt .prims .INV/] ], [ "All files", '*' ], );
    my $filepath =
      $mw->getOpenFile( -initialdir => $lastD, -filetypes => \@types )
      or return ();
    $filepath = checkpath($filepath);
    my $entry = $_[0];
    $entry->delete( '0.0', 'end' );
    $entry->insert( 0, $filepath );
    $lastD =  dirname($filepath);
    setLastD();
    return ($filepath);
}

#### Get Directories paths needed for Spoon processes
sub getDir {
    getlastD();
    my $dir = $mw->chooseDirectory(
        -initialdir => $lastD,
        -title      => 'Choose a folder'
    );
    if ( !defined $dir ) {

    }
    else {
        my $entry = $_[0];
        $dir = checkpath($dir);
        $entry->delete( '0.0', 'end' );
        $entry->insert( 0, $dir );
        $lastD = $dir;
        setLastD();
    }
}



#### Check if paths does not contain spaces
sub checkpath {
    my ($path) = @_;
    if ( $path =~ m/\s/g ) {
        my $answer = $mw->Dialog(
            -title          => 'Please Reply',
            -text           => 'Spaces in paths are not allowed !',
            -default_button => 'ok',
            -buttons        => ['ok'],
            -bitmap         => 'warning'
        )->Show();
        if ( $answer eq 'ok' ) {
            return "please select path";
        }

    }
    return $path;
}

sub Processfinished {
       
            my($outputdir)=@_;  
            my $answer = $mw->Dialog(
            -title          => 'Spoon is Done !',
            -text           => 'Spoon has finsihed tasting at results are stored in : '.$outputdir,
            -default_button => 'ok',
            -buttons        => ['ok'],
        )->Show();
        if ( $answer eq 'ok' ) {
        }
       
       
       
}



##### Create Config. File from User Selections and paramters and Run selected processes
sub GOGO {
    #Create conf. file
    create_conf();
    # RUN INS PCR
    runspoon();
}

sub create_conf {
    open( CONFILE, ">Config/config.info" );
    foreach my $g (@TEXTBOXLIST) {
        print CONFILE $g->[1] . $g->[0]->get() . "\n";

    }
    print CONFILE "DOINSILICO=" . $DOINSILICO . "\n";
    print CONFILE "EXTRACTAMPS=" . $EXTRACTAMPS . "\n";
    print CONFILE "PCRSTAT=" . $PCRSTAT . "\n";
    print CONFILE "GENESAROUND=" . $GENESAROUND . "\n";
    print CONFILE "PCRALIGN=" . $PCRALIGN . "\n";
    print CONFILE "PCRCIRCOS=" . $PCRCIRCOS . "\n";
    print CONFILE "CREATEDIR=" . $CREATEDIR . "\n";
    print CONFILE "AlIGNINVITROTO=" . $ALIGNV . "\n";
    print CONFILE "ANNOTEFILETYPE=".$Annot. "\n"; 
    


    close CONFILE;
}


sub runspoon
{



ECHO("Starting new process");

my %config = user_config::readconfigfile();
my $outputdir = $config{"OUTDIR"}.$config{PLATDIR};
######################	Create Information files from Seq(s) and user configurations
user_config::createinfofiles(\%config);

######################	Start selected processes
######################	If In silico PCR has been chosen 
   if ( $config{"DOINSILICO"} eq "YES" ) {
       MainSpoon::ins_pcr_c_code(\%config);
ECHO("In silico PCR");
    }   
######################	If PCR Statistics has been chosen 
    if ( $config{"PCRSTAT"} eq "YES" ) {       
       covstatics::getstat();   
ECHO("In silico PCR coverage analysis");
    }
######################	If in silico amplicons extraction has been chosen 
    if ( $config{"EXTRACTAMPS"} eq "YES" ) {
        MainSpoon::extractinsamp(\%config);
ECHO("retriving in silico PCR amplicons sequences from FASTA file(s)");
    }
######################	Searching for amplicons adjoin or near genes 
    if ( $config{"GENESAROUND"} eq "YES" ) {

ECHO("Searching for PCR amplicons near or adjoin genes");
                    my $glocfile=$config{"OUTDIR"}.$config{PLATDIR}."Seq_Genes_Loc.txt"; 
		    #If user providede genbank annotation files
                    if($config{ANNOFILE} eq "GB")
		    {
                     genesaround::createglocfilefromgb(\%config);
		     $config{ANNOFILE} = $glocfile; 
		    }
                    #if user provided list files
		    if($config{ANNOFILE} eq "LIST")
		    {
                    genesaround::createglocfilefromlist(\%config);
                    $config{ANNOFILE} = $glocfile; 
		    }
           genesaround::getgenesaround(\%config);
    }
#####################	Comparing in silico amplicons to in vitro amplicons	

if ( $config{"PCRALIGN"} eq "YES" ) {
ECHO("Comparing in silico and in vitro PCR amplicons according to MW and Pb length");
 my @matches=insinvcompare::compare_ins_inv(\%config);
 insinvcompare::print_ins_inv_Amps(\%config,\@matches);
	
               #create circos conf. for ins-inv comparison
               if ( $config{"PCRCIRCOS"} eq "YES" ) {
ECHO("Creating Circos Config. for In silico - In vitro Comparison") ;
                  ############ Circos configuration for align in-ins comparison 
		  mkdir $outputdir . "CircosAlign";
		  insinvcompare::create_def_circosalign(\%config,\@matches,$outputdir . "CircosAlign");
		  insinvcompare::print_bands_highlights(\%config,\@matches,$outputdir . "CircosAlign");
		  insinvcompare::print_links_file(\%config,\@matches,$outputdir . "CircosAlign");
		  my $genes=0;
		  if($config{"AlIGNINVITROTO"}=~m/G/g){$genes=1;}
		  templates::createcircoalignconf($outputdir . "CircosAlign".$config{PLATDIR},$genes);
		  if($genes==1)
		  {
		  insinvcompare::print_genes_file_circos_align(\%config,\@matches,$outputdir . "CircosAlign".$config{PLATDIR});
		  } 
               }
          
    }
########################### Create circos conf for in silico Stat.
if ( $config{"PCRCIRCOS"} eq "YES" ) { 
ECHO("Creating Circos Config. for In silico coverage analysis") ;
	my %covarea = MainSpoon::readcoveredareas(\%config);
	my @colors=MainSpoon::colors();
	my @parray=sort { lc($a) cmp lc($b) } keys(%covarea);
	my %pn = circosconf::get_prims_n_for_inscircos(\%config);
	my $coutputdir = $config{"OUTDIR"}.$config{PLATDIR}."Circos";
	######## These are statistics
	my %anchorprims = covstatics::get_anchor_prims(\%covarea);
	covstatics::print_anchor_pfile(\%anchorprims,\%config);
	############ make dir for circos config
	mkdir $coutputdir ;
	circosconf::create_PsetBand_file(\%pn,\%config,$coutputdir);
	circosconf::print_link_Pset_hit(\@parray,\%covarea,\%pn,$coutputdir,\@colors,\%config);
	my @stats=circosconf::get_cov_stat_for_circos(\%covarea,\@parray);
	#primer coverage statistics
	my %pcstatistics=%{$stats[0]};
	#primer set coverage statistics
	my %pstatistics=%{$stats[1]};
	# Seq areacoverage statistics 
	my %cstatistics=%{$stats[2]};
	# Total area covered by all p. set
	my $tatolcover=$stats[3];
	circosconf::print_circos_statics($coutputdir,\%pcstatistics,\%pstatistics,
	\%cstatistics,$tatolcover,\%config,\%pn,\%anchorprims);
	my %areas=covstatics::get_all_covered_areas(\%covarea,\@parray);
	########### get max chrom for circos
	my $maxchrom = covstatics::get_max_Seq_length(\%areas);
	circosconf::print_def_statcircos(\%areas,\%pn,$coutputdir,\%config);
	########### Genes file
	circosconf::print_genes_statcircos(\%config,$coutputdir,\%areas);
	######### Hit links
	circosconf::print_hitlinks_statcircos(\@colors,\%config,$coutputdir,\%pn,\%areas);
	templates::createcircosconf($coutputdir.$config{PLATDIR},$maxchrom);

 }


######################################### Create finished process report
######################################### Create Report Table
ECHO("Creating Spoon report"); 
    my $insfile     = $outputdir . "In_silico_PCR_Results.csv";
    my $ingfile     = $outputdir . "In_silico_PCR_near_or_adjoin_genes.csv";
    my $insinvfile  = $outputdir . "INS_INV_Amps.txt";
    my $covstatfile = $outputdir . "Coverage_statistical_analysis_output_by_base_pair.csv";
    my $allinsbands = 0;
    my $tgenes      = 0;
    my $totalcov    = 0;
    my $totalcovper = 0;
    my $anchc       = 0;
    my @allprimers=MainSpoon::get_primers_names_from_file(\%config);

    ##If these results existed add to report
    my %ft = ();
    stat($insfile);              
    if ( -e _ ) {
         ECHO("Reading in silico FILES");                  
        my @out = report::readins($insfile,\%ft,$allinsbands);
        %ft=%{$out[0]};
        $allinsbands=$out[1];
          
    }
    stat($covstatfile);
    if ( -e _ ) {
        my @cout = report::covstat($covstatfile,\%ft,$totalcov);
        %ft=%{$cout[0]};
        $totalcov=$cout[1];
        my @statout = report::covper( $outputdir . "Coverage_statistical_analysis_output_by_percentage.csv",\%ft,$totalcovper);
        %ft=%{$statout[0]};
        $totalcovper=$statout[1];
        ECHO("Reading in silico coverage FILES");
    }

    stat($ingfile);
    if ( -e _ ) {
        %ft = report::reading($ingfile,\%ft);
        my @gout=report::get_agene_count_and_anchror_chr(\%ft);  
        $tgenes=$gout[0]; 
        $anchc=$gout[1];
   
       ECHO ("Reading Genic in silico FILES");
    }

    stat($insinvfile);
    if ( -e _ ) {
         %ft = report::readinvins($insinvfile,\%ft);
        ECHO("Reading in vitro in silico Comparison  FILES");
    }
     
################################# print table
    ECHO("Printing report");
    report::print_report_table(\%ft,$outputdir);

######################################### Create Report Text

    open( RTTXT, ">" . $outputdir . "Report_text.txt" );
    print RTTXT "Total number of primers :" . "\t"
      . ( $#allprimers + 1 )
      . "\tprimer(s)\n";
    print RTTXT "Total number of primers with hits :" . "\t" .
      keys(%ft) . "\tprimer(s)\n";
    print RTTXT "Total number of insilico bands :" . "\t"
      . $allinsbands
      . "\t band(s)\n";
    print RTTXT "Total number of genic insilico bands :" . "\t" . $tgenes
      . "\t gene(s)\n";
    print RTTXT "Genome Coverage :" . "\t"
      . $totalcov
      . "bp\t which about $totalcovper% of the total area\n";
    print RTTXT "Primers exists in one chr (anchor) :" . "\t" . $anchc
      . "\tprimer(s)\n";
    close RTTXT;

############################################## END

ECHO("SPOON has FINISHED");
}

sub ECHO {
    my ($say) = @_;

    tie *STDOUT, ref $ProgText, $ProgText;
    print "$say\n";
    $mw->update;

}
$mw->MainLoop();
