package covstatics;
use strict;
use List::Util qw[min max];
use user_config;

sub getstat
{
my %config      = user_config::readconfigfile();
my $seqinfofile=$config{"OUTDIR"}.$config{PLATDIR}."seq.info";
my $keycodefile=$config{"OUTDIR"}.$config{PLATDIR}."keycode.info";
my $outfile=$config{"OUTDIR"}.$config{PLATDIR}."In_silico_PCR_Results.csv";
my $outcovfile=$config{"OUTDIR"}.$config{PLATDIR}."CoveredAreas.csv";
my $outputdir   = $config{"OUTDIR"}.$config{PLATDIR};

my %seqinfos     = user_config::readseqinfo($seqinfofile);
my %seqkeys      = user_config::readseqkey($keycodefile);
my $totallength  = totallength(\%seqinfos);

my %acccov = user_config::readcov($config{"PCOVAREA"});
$config{"PCOVAREA"} = \%acccov;
my %PAacc       = getbypbyaccforstatistics($outfile);
my %copamps     = collectamps(\%PAacc,\%config);  
my %copcov      = getcollected(\%copamps,\%config,\%seqkeys,$outcovfile);
printcov($outputdir,\%config,\%seqkeys,\%copcov,$totallength);
}


sub printcov {
    my($outputdir,$config,$seqkey,$copcov,$totallength)=@_;
    my %seqkey=%{$seqkey};
    my %config=%{$config};
    my %copcov=%{$copcov}; 
    #collect keys which are in the config file
    my @areakeys = getkeysarray(\%config);
    #print results
    open(RNFILE,">".$outputdir."Coverage_statistical_analysis_output_by_base_pair.csv");
     open(RSFILE,">".$outputdir."Coverage_statistical_analysis_output_by_percentage.csv");
    #print the accs required
    print RNFILE "PrimerName,PrimerALLCoverage,";
    print RSFILE "PrimerName,PrimerALLCoverage,";
     foreach my $ck (@areakeys) {
        if ( $seqkey{ $ck->[1] } ) 
        {
            if (  $ck->[2]   == 0 &&   $ck->[3]  == 0 ) {
                print RNFILE $seqkey{ $ck->[1] }. ",";
                print RSFILE $seqkey{ $ck->[1] }. ",";
                }
            else {
                print RNFILE $seqkey{ $ck->[1] } . ":"
                  .  $ck->[2]  . ":"
                  .  $ck->[3]   . ",";
               print RSFILE $seqkey{ $ck->[1] } . ":"
                  .  $ck->[2]  . ":"
                  .  $ck->[3]   . ",";
                 }
        }
        else
        {
           print RNFILE $ck->[1]  . ":"
                  .  $ck->[2]  . ":"
                  .  $ck->[3]   . ",";
        } 
    
    
    }
 
     #Total of all
     my @primers = returnprimernams(\%copcov);
     print RNFILE "\n";
     print RSFILE "\n";
        foreach my $primer (@primers ) 
        {
        print RNFILE $primer. "," . $copcov{$primer}->{"total"} .",";
        print RSFILE $primer. "," .sprintf("%.7f", (( $copcov{$primer}->{"total"} /$totallength)*100)).",";
        
        
        foreach my $ck (@areakeys) { 
            print RNFILE $copcov{$primer}->{$ck->[0]} . ","; 

         
            print RSFILE sprintf("%.8f", (($copcov{$primer}->{$ck->[0]}/($ck->[3]-$ck->[2]))*100)) . ",";
            }
        print RNFILE "\n";
        print RSFILE "\n"; 
       }
     
     
     
     
     
close   RNFILE;
close   RSFILE;

}



sub returnprimernams
{
        my($copcov)=@_;
        my %copcov=%{$copcov};    
        my @names  ;
        foreach my $p (keys(%copcov))
        {

            if($p ne "PrimerSet" )
            {
               push (@names,$p);
            }
        } 
        push (@names,"PrimerSet");
      return @names;
}


sub getkeysarray
{
    my($config)=@_;
    my %config=%{$config}; 
    my @areakeys;
    foreach my $key ( keys( %{$config{"PCOVAREA"}} ) ) {         
        foreach my $part ( @{ $config{"PCOVAREA"}->{$key} } ) {
                  
            push( @areakeys,
                [ @{$part}[2], @{$part}[3], @{$part}[0], @{$part}[1] ] );
        }
    }
    return @areakeys;
}


sub getcollected {
    my ($pcov,$config,$seqkey,$file) = @_;
    my %pcov=%{$pcov};
    my %config=%{$config};
    my %seqkey=%{$seqkey}; 
    #contains the primer coverage
    my %pcoverage;
open (COVFILE,">".$file);
    # for every primer
    foreach my $p ( keys(%pcov) ) {
         
        #the primer total coverage for all accessions
        my $ptotalcover = 0;

        # for every accession
        foreach my $cc ( keys( %{ $pcov{$p} } ) ) {
            my $kc = $cc;
            $kc =~ s/\s//g; 
             # foreach collected part in this accession regarding this primer

            foreach my $c ( @{ $pcov{$p}->{$cc} } ) {
                $ptotalcover += ( @{$c}[1] - @{$c}[0] );
                
	         #If this accession is coverage required
                if ( $config{"PCOVAREA"}->{$kc} ) {
                       
                    # for each accession holds array of parts required
                    foreach my $ACC ( $config{"PCOVAREA"}->{$kc} ) {
                        
                        #foreach part
                        foreach my $part ( @{$ACC} ) {
                            
                            my $pkey   = @{$part}[2];
                            my $pstart = @{$part}[0];
                            my $pend   = @{$part}[1];
                            my $seqnam =@{$part}[3];
                            my $printkey = $pkey;
                            if ( $seqkey{$seqnam} )
                            {
                                 
                                $printkey = $seqkey{ @{$part}[3]}.":".$pstart.":".$pend;
                            }
                            
                            #these mean that the start is the start of the acc and the end is the end of the acc
                            if ( $pend == 0 ) {
                                $pend = 10000000000000;
                            
                             }
                            my $maxstart = max( $pstart, @{$c}[0] );
                            my $minend = min( $pend, @{$c}[1] );
                            if ( $maxstart < $minend ) 
                            {
                                $pcoverage{$p}->{$pkey} +=
                                  ( $minend - $maxstart );
                             
                            if($p ne "PrimerSet")
                            {

                                print  COVFILE $p.","."$printkey".",".$maxstart.",".$minend."\n";
                            }
                            }
                        }
                    }
                }
            }

            #if this accession exists in our accessions report
            #I think this is unexplained
            $pcoverage{$p}->{"total"} = $ptotalcover;           
        }
    }
     close COVFILE;     
    return %pcoverage;
}














sub totallength {
    my($seqinfofile)=@_;
    my %seqinfofile=%{$seqinfofile};  
    my $totallength;
    foreach my $key ( keys(%seqinfofile) ) {
        $totallength += $seqinfofile{$key};
    }
    return $totallength;
}

sub getbypbyaccforstatistics {
    my ($file) = @_;

# the idea is to store ins. data by primer contains hits in acc and also for all primers store all primers hits
    my %pamps;
    my %insresult = readinsresult($file);
    foreach my $key ( keys(%insresult) ) {
        
        foreach my $Array ( @{ insresult { $key } } ) {
            foreach my $amp ( @{$Array} ) {
                my %myamp = %{$amp};
                my $pnam  = $myamp{"pnam"};
                my $acc   = $myamp{"seqnam"};
               
              push( @{ $pamps{$pnam}{$acc} }, \%myamp );
              my %tot = %myamp;
              $tot{"pnam"}="PrimerSet";
              push( @{ $pamps{"PrimerSet"}{$acc} }, \%tot );       
            }
        }
    }
    return %pamps;
}

sub getbypbyaccforstatisticsbykey {
    my ($file,$key) = @_;
    my %key=%{$key};
# the idea is to store ins. data by primer contains hits in acc and also for all primers store all primers hits
    my %pamps;
    my %insresult = readinsresult($file);
    foreach my $key ( keys(%insresult) ) {
        
        foreach my $Array ( @{ insresult { $key } } ) {
            foreach my $amp ( @{$Array} ) {
                my %myamp = %{$amp};
                my $pnam  = $myamp{"pnam"};
                my $acc   = $key{$myamp{"seqnam"}};
               
              push( @{ $pamps{$pnam}{$acc} }, \%myamp );
              my %tot = %myamp;
              $tot{"pnam"}="PrimerSet";
              push( @{ $pamps{"PrimerSet"}{$acc} }, \%tot );       
            }
        }
    }
    return %pamps;
}

sub print_anchor_pfile
{
my($anchorprims,$config)=@_;
my %anchorprims=%{$anchorprims};
my %config=%{$config};

open(ANPFILE,">".$config{"OUTDIR"}.$config{PLATDIR}."Anchor_primers.csv");
foreach my $p(keys(%anchorprims))
{
my $ck=$anchorprims{$p}{"area"};
my $start=$anchorprims{$p}{"start"};
my $end=$anchorprims{$p}{"end"};
print ANPFILE $p.",".$ck.",".$start.",".$end."\n";       
}
close ANPFILE;
}

sub readinsresult {
    my %insresult;
    my ($file)=@_;
    my %in;           
    open( FILE, "<$file" );
    while (<FILE>) {
       
        chomp();
        my $this=$_;
           $this=~s/\s//g;
        if(!$in{$this})
        {  
        my @line = split( ",", $this );
        my %amp = amp(@line);
        if ( $amp{"pnam"} ne "Primer Name" && $amp{"pnam"} ne "PrimerName" ) {
            push( @{ $insresult{ $line[0] } }, \%amp );           
        }
        }
        $in{$this}=1;  
     
    }
    close FILE;

    return %insresult;
}
sub amp {
    my %amp;
    my (@line) = @_;
    $amp{"pnam"} = $line[0];
    $amp{"pf"}     = $line[1];
    $amp{"pr"}     = $line[2];
    $amp{"aml"}    = $line[3];
    $amp{"fhmis"}  = $line[4];
    $amp{"rhmis"}  = $line[5];
    $amp{"seqnam"} = $line[6];
    $amp{"fpos"}   = $line[7];
    $amp{"rpos"}   = $line[8];
    $amp{"gene"}   = $line[9];
    $amp{"all"}    = "@_";
    return %amp;
}



sub collectamps {
    my($pamps,$config)=@_;
    my %config=%{$config};
    my %pamps=%{$pamps}; 
    #take every primer
    my %pchash;
    foreach my $p ( keys(%pamps) ) {
        #holds collected parts
          
        #take every accession in that primer
        foreach my $acc ( keys( %{ $pamps{$p} } ) ) {              

             $pchash{$p}->{$acc} = collapse(\@{ $pamps{$p}->{$acc}},\%config);
        }
    }
    #return hash
    return %pchash;
}
sub collapse
{
        my($inarray,$config) = @_;
        my %config=%{$config};
        my @inarray=@{$inarray};
        my @acarray;
        #To print covered areas
         
        #sort the array of hashes inside the primer hash refernce  by start pos
        @inarray = sort { $a->{"fpos"} <=> $b->{"fpos"} } @inarray;
        #take the first start and end 
            my ( $cstart, $cend ) = (
                $inarray[0]->{"fpos"},
                $inarray[0]->{"rpos"}
            );

      foreach my $c ( @inarray ) 
      {
             
                my $maxstart = max( $cstart, $c->{"fpos"} );
                
                my $minend = min( $cend, $c->{"rpos"} );
                if ( $maxstart <= $minend + $config{"MAXGAPBAMP"} ) {
                    $cstart = min( $cstart, $c->{"fpos"} );
                    $cend = max( $cend, $c->{"rpos"} );
                       
                }
                else {
                    push( @acarray, [ $cstart, $cend ] );
                    $cstart = $c->{"fpos"};
                    $cend   = $c->{"rpos"};
                     
                }
        }  
            push( @acarray, [ $cstart, $cend ] );
            
            return  \@acarray;
}
sub get_anchor_prims
{

        my($covarea)=@_;
        my %covarea=%{$covarea};
        my %anchorprims;

	foreach my $p (keys(%covarea))
	{
		 my $pcount = 0;
		 my $ancharea;
		 foreach my $cov (keys($covarea{$p}))
		 {
		   $ancharea=$cov;
		   $pcount++;
	 	 }
		 if($pcount==1)
		 {
		        my @array=@{$covarea{$p}{$ancharea}};
		        $anchorprims{$p}{"area"}=$ancharea;
		        $anchorprims{$p}{"start"}=$array[0][0];
		        $anchorprims{$p}{"end"}=$array[0][1];
		 }
	}

return %anchorprims;
}

sub get_all_covered_areas
{
my($covarea,$parray)=@_;
my @parray=@{$parray};
my %covarea =%{$covarea};
my %areas;
	foreach my $p (@parray)
	{
		foreach my $cov (keys($covarea{$p}))
			 {
		    $areas{$cov}=1;
		}
	}
return %areas;
}


sub get_max_Seq_length
{
my($areas)=@_;
my %areas=%{$areas};
my $maxchrom;
foreach my $r (keys(%areas))
{
 my ($chr,$str,$end)=split(/:/,$r);
 $r=~s/:/\_/g; 
 if($maxchrom<=($end-$str)){$maxchrom=($end-$str)};  
}
return $maxchrom;
}

1;

