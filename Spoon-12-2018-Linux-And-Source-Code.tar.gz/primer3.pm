package primer3;
use Exporter qw/import/;
our @EXPORT_OK =
  qw/get_primers print_params read_p3_out read_spoon_out create_p3_pram return_pvar print_p_check create_pcheck run_primer3 return_mean read_p3check_out word_fit word print_pchick_result/;

sub get_primers {
    my ($p3params,$file)=@_;
    system("./bin/primer3_core $p3params > $file");
}
sub run_primer3
{
 my($infile,$outfile)=@_;
    system("./bin/primer3_core $infile > $outfile"); 
}
sub create_p3_pram {
    my ($snps,$params,$p3file)=@_;
    my %params=%{$params};
    my %snps=%{$snps};
    #clear params file
    $params{"P3IN"} = $p3file;
    open( P3FILE, ">" . $params{P3IN} );
    close P3FILE;
    foreach my $seq ( keys(%snps) ) {
        $params{"SEQUENCE_ID"} = $seq;
        #remove [G/A]
        my $newseq = $snps{$seq};
        if ( $snps{$seq} =~ m/\[(\w)\/(\w)\]/g ) {
            $newseq =~ s/\[(\w)\/(\w)\]/X/g;
        }
        $params{"SEQUENCE_TEMPLATE"} = $newseq;
         print_params(%params);
    }

}

sub read_p3check_out {
    my ($file) = @_;
    open( FILE, $file );
    my %idents;
    my ( $seqid, $pnumber, $pleftnumber, $pvarnumber, $ABseq, $Cseq );
    while (<FILE>) {
        chomp();
        my $line = $_;
                                                   
        if ( $line =~ m/SEQUENCE_ID=(\S+)\+(\d+)\$([A|B|C])\_VAR(\d+)\#(\S+)\#(\w+)\-(\d+)\-(\d+)\-(\d+)/g )
        {
            my ($lpos,$rpos,$prol);
            ($seqid,$pnumber,$pleftnumber,$ABseq,$Cseq,$lpos,$rpos,$prol)=get_prim_info($line);
            $Aseq=$ABseq;
            $Aseq=~s/\[(\w)\/(\w)\]/\1/g;
            $Bseq=$ABseq;
            $Bseq=~s/\[(\w)\/(\w)\]/\2/g;
            
            $idents{$seqid}{$pnumber}{"prims"}=[$Aseq,$Bseq,$Cseq];            
           
            $idents{$seqid}{$pnumber}{$pleftnumber}{"lpos"}=$lpos;
            $idents{$seqid}{$pnumber}{$pleftnumber}{"rpos"}=$rpos;
            $idents{$seqid}{$pnumber}{$pleftnumber}{"prol"}=$prol;
            $idents{$seqid}{$pnumber}{$pleftnumber}{"consider"}++;
            
            if($idents{$seqid}{"pns"}<$pnumber){$idents{$seqid}{"pns"}=$pnumber; }
        }
        elsif ( $line =~ m/(\S+)\=(\S+)/ ) 
        {
            my $paraname = $1;
            my $value    = $2;
            push(
                @{
                    $idents{$seqid}{$pnumber}{$pleftnumber}{$paraname}{"values"}
                },
                $value
            );
            $idents{$seqid}{$pnumber}{$pleftnumber}{$paraname}{"total"} +=
              $value;
        }
        if ( $line =~ m/ok 0/ ) {
            if ( $line =~ m/, ([\S|\s]+) 1,/ ) {
                $idents{$seqid}{$pnumber}{$pleftnumber}{"fails"}{$1}++;
            }
            $idents{$seqid}{$pnumber}{$pleftnumber}{"failed"}++;
        }
        
    }
    close FILE;
    return %idents;
}

sub get_prim_info
{
    my ($head)=@_;
    if ( $head =~ m/SEQUENCE_ID=(\S+)\+(\d+)\$([A|B|C])\_VAR(\d+)\#(\S+)\#(\w+)\-(\d+)\-(\d+)\-(\d+)/g )
        {
         return ($1,$2,$3,$5,$6,$7,$8,$9);
        }
    }
sub read_spoon_out {
    my ($file) = @_;
    my %snps;
    open( FILE, $file );
    while (<FILE>) {
        my @lines = split( /,/, $_ );
        $snps{ $lines[0] } = $lines[1];
    }
    close FILE;
    return %snps;
}

sub return_pvar {
    my ($sq) = @_;
    my @seq = split( //, $sq );
    my %primerpos;
    %primerpos = return_primer_var( \@seq, \%primerpos );
    return keys(%primerpos);
}

sub print_p_check {
    my ( $seqid, $pn, $pseq ) = @_;
    return "SEQUENCE_ID=$seqid\+$pn
SEQUENCE_PRIMER=$pseq
PRIMER_TASK=check_primers
PRIMER_INTERNAL_SALT_MONOVALENT=50.0
PRIMER_INTERNAL_DNA_CONC=50.0
PRIMER_SALT_MONOVALENT=50.0
PRIMER_SALT_CORRECTIONS=1
PRIMER_SALT_DIVALENT=1.5
PRIMER_TM_FORMULA=1
PRIMER_MAX_SIZE=36
PRIMER_MIN_SIZE=18
PRIMER_MIN_TM=20
PRIMER_EXPLAIN_FLAG=1
PRIMER_THERMODYNAMIC_PARAMETERS_PATH=bin/primer3_config/
=\n";

}
sub return_mean
{
  my ($total,$count)=@_;    
  if($count==0){return "Faild"}
  else{return $total/$count}  
}        
sub create_pcheck
{
my($poutfile,$pcheckfile)=@_;
open(PCFILE,">".$pcheckfile);

my %idents = read_p3_out($poutfile);
for my $i ( keys(%idents) ) {
    my ( $ptarget_A, $ptarget_B );
    #Get SNP var
    if ( $i =~ m/-(\w)-(\w)/ ) { $ptarget_A = $1; $ptarget_B = $2; }
    #Handle Every Primer
    for my $p ( 0 .. $idents{$i}{"pn"} ) {
                 my $pseq_r = $idents{$i}{$p."R"}{"PRIMER_RIGHT_SEQUENCE"};
                 my $pseq_l = $idents{$i}{$p."L"}{"PRIMER_LEFT_SEQUENCE"};
                 my $plpos=$idents{$i}{$p."L"}{"PRIMER_LEFT"};
                 my $prpos=$idents{$i}{$p."R"}{"PRIMER_RIGHT"};
                 my $poslength=$idents{$i}{$p."R"}{"PRIMER\_PAIR\_PRODUCT\_SIZE"};
                 my $pseq_l_or=$pseq_l;
                    $pseq_l_or=~s/X/\[$ptarget_A\/$ptarget_B\]/g;
                $pvarn=0;
                for my $var_l ( return_pvar($pseq_l) ) {
                    my $tpseq=$var_l;
                    $tpseq=~s/X/$ptarget_A/g;
                    $var_l=~s/X/$ptarget_B/g;
                    print PCFILE print_p_check($i,$p."\$A_VAR$pvarn\#$pseq_l_or\#$pseq_r"."-".$plpos."-".$prpos."-".$poslength,$tpseq);
                    print PCFILE print_p_check($i,$p."\$B_VAR$pvarn\#$pseq_l_or\#$pseq_r"."-".$plpos."-".$prpos."-".$poslength,$var_l);                     
                $pvarn++;
                }
                $pvarn=0;
                for my $var_r ( return_pvar($pseq_r) ) {
                    print PCFILE print_p_check($i,$p."\$C_VAR$pvarn\#$pseq_l_or\#$pseq_r"."-".$plpos."-".$prpos."-".$poslength,$var_r);
                }
                
    }

}
close PCFILE;
}

sub print_params {
    my (%params) = @_;
    open( P3FILE, ">>" . $params{P3IN} );
    foreach my $par ( keys(%params) ) {
        if ( $par ne "P3IN" ) {
            print P3FILE $par . "=" . $params{$par} . "\n";
        }
    }

    print P3FILE "=\n";
    close P3FILE;
}

my %idents;

sub read_p3_out {
    my ($file) = @_;
    open( FILE, $file );
    $tseq;
    my $pn;
    while (<FILE>) {
        chomp();
        my $line = $_;
        if ( $line =~ m/SEQUENCE_ID=(\S+)/g ) {
            $tseq = $1;
        }
        if (/\_(\d+)\S+\=/) {

            #primer number
            $pn = $1;
            if ( $idents{$tseq}{"pn"} < $pn ) { $idents{$tseq}{"pn"} = $pn; }
            if ( $line =~ /(\S+)\=(\S+)/ ) {
                my $ident = $1;
                my $value = $2;
                my $dir   = "R";
                if ( $ident =~m/LEFT/g ) { $dir = "L"; }
                $ident =~ s/\_\d+//g;
                $idents{$tseq}{ $pn . $dir }{$ident} = $value;
            }
        }
        if($line=~m/PRIMER\_LEFT\_(\d+)=(\d+)\,(\d+)/)
          {
              $idents{$tseq}{ $1 . "L" }{"PRIMER_LEFT"} = $2;
          }
        if($line=~m/PRIMER\_RIGHT\_(\d+)=(\d+)\,(\d+)/)
          {
              $idents{$tseq}{ $1 . "R" }{"PRIMER_RIGHT"} = $2;
          }
        if($line=~m/PRIMER\_PAIR\_(\d+)\_PRODUCT\_SIZE=(\d+)/)
          {
              $idents{$tseq}{ $1 . "R" }{"PRIMER\_PAIR\_PRODUCT\_SIZE"} = $2;
          }
            
          #PRIMER_PAIR_0_PRODUCT_SIZE           
    }
    close FILE;
    return %idents;
}

sub return_primer_var {
    my ( $seq, $primerpos ) = @_;
    my @seq = @{$seq};
    my %snpv;
    %primerpos = %{$primerpos};
    $snpv{"M"} = [ ( "A", "C" ) ];
    $snpv{"R"} = [ ( "A", "G" ) ];
    $snpv{"W"} = [ ( "A", "T" ) ];
    $snpv{"S"} = [ ( "G", "C" ) ];
    $snpv{"Y"} = [ ( "T", "C" ) ];
    $snpv{"K"} = [ ( "G", "T" ) ];
    for my $n ( 0 .. $#seq ) {

        if ( $snpv{ $seq[$n] } ) {
            my @pos = @{ $snpv{ $seq[$n] } };
            $seq[$n] = $pos[0];
            return_primer_var( \@seq, \%primerpos );
            $seq[$n] = $pos[1];
            return_primer_var( \@seq, \%primerpos );
        }
    }
    $primerpos{ join( "", @seq ) } = 1;
    return %primerpos;
}
sub word_fit
{
    my($word)=@_;
    my $length=length($word);
    $length=12-$length;
    $length/=2;
    for (0..$length)
    {
        $word =" ".sprintf("%.2f",$word)." "; 
        
    }
return $word;
}

sub word
{
    my($word)=@_;
    my $length=length($word);
    $length=12-$length;
    $length/=2;
    for (0..$length)
    {
        $word =" ".$word." "; 
        
    }
return $word;
}



sub print_pchick_result
{
my($checkinfo,$file)=@_;
%checkinfo=%{$checkinfo};
my @info_list = qw(PRIMER_END_STABILITY
  PRIMER_LEFT_0_PENALTY
  PRIMER_LEFT_0_TM
  PRIMER_LEFT_0_GC_PERCENT
  PRIMER_LEFT_0_SELF_ANY_TH
  PRIMER_LEFT_0_SELF_END_TH
  PRIMER_LEFT_0_HAIRPIN_TH
  PRIMER_LEFT_0_END_STABILITY
);
open(PRESULT,">".$file);
print PRESULT "NUMBER of SNPS with primers:".keys(%checkinfo)."\n";
for my $seqid ( keys(%checkinfo) ) {
    print PRESULT "%%%%%%%%%%%%%%%%%%%%% SNPID: $seqid Number_of_Primers_Returned ".$checkinfo{$seqid}{"pns"}."%%%%%%%%%%%%%%%%\n";
    for my $pnumber ( 0..$checkinfo{$seqid}{"pns"}  ) {
        
        my @prims=@{$checkinfo{$seqid}{$pnumber}{"prims"}};
        print  PRESULT "###############SNPID:".$seqid."\tPrimerGroupNumber:".$pnumber."  ###############\n";
        print  PRESULT "--------------General Primers Informations-----------------------------------\n";
        print  PRESULT "Primer_A_Sequence:      ".$prims[0]."\n";
        print PRESULT "Primer_B_Sequence:      ".$prims[1]."\n";
        print PRESULT  "Primer_C_Sequence:      ".$prims[2]."\n";
        print PRESULT  "Left_Primers_Position:  ".$checkinfo{$seqid}{$pnumber}{"A"}{"lpos"}."\n";
        print PRESULT  "Common_Primer_Position: ".$checkinfo{$seqid}{$pnumber}{"A"}{"rpos"}."\n";
        print PRESULT  "Product_Length:         ".$checkinfo{$seqid}{$pnumber}{"A"}{"prol"}."\n";
        print PRESULT  "--------------Specific Primers Informations-----------------------------------\n";
        my  $considerA = $checkinfo{$seqid}{$pnumber}{"A"}{"consider"};
        my  $considerB = $checkinfo{$seqid}{$pnumber}{"B"}{"consider"};
        my  $considerC = $checkinfo{$seqid}{$pnumber}{"C"}{"consider"};
        
        my $failsnA =$checkinfo{$seqid}{$pnumber}{"A"}{"failed"}+0;
        my $failsnB =$checkinfo{$seqid}{$pnumber}{"B"}{"failed"}+0;
        my $failsnC =$checkinfo{$seqid}{$pnumber}{"C"}{"failed"}+0;
        
        #by seqid and primers
        my $countA= $considerA-$failsnA;
        my $countB= $considerB-$failsnB;
        my $countC= $considerC-$failsnC;
        print PRESULT  "INFO                    A\tB\tC\n";
        
        print PRESULT   word_fit("Primer_Variants_CONSIDERED  ").word_fit($considerA)."".word_fit($considerB)."".word_fit($considerC)."\n";
        print PRESULT   word_fit("Primer_Variants_FAILED      ")."".word_fit($failsnA).word_fit($failsnB).word_fit($failsnC)."\n";
        for my $info (@info_list) {            
            $valueA=$checkinfo{$seqid}{$pnumber}{"A"}{$info}{"total"};
            $valueB=$checkinfo{$seqid}{$pnumber}{"B"}{$info}{"total"}; 
            $valueC=$checkinfo{$seqid}{$pnumber}{"C"}{$info}{"total"};
            my $paramane=$info; 
            $paramane=~s/PRIMER\_LEFT\_0\_//g;
            print PRESULT  word($paramane)."\t".word_fit(return_mean($valueA,$countA)).word_fit(return_mean($valueB,$countB)).word_fit(return_mean($valueC,$countC))."\n"; 
           } 
    }
}
close PRESULT;
}
return 1;
