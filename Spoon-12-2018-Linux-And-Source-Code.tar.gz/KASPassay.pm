package KASPassay;

sub select_snps_nearby
{
my ($Rfile,$snpDfile,$databasetype,$snpDistance,$outfile)=@_;

my %insloc;
open( GLOC, $Rfile );
while (<GLOC>) {
    chomp();
    my @line = split( /\,/, $_ );
    push( @{ $insloc{ $line[6] } }, [ $line[7], $line[8], $line[0]."\|".$line[3]."\|".$line[9] ] );
    
}
close GLOC;

my %SNPsloc;

# Read SNP database 
 if($databasetype eq "LIST")
 {

open( SNPLOC, $snpDfile );
while (<SNPLOC>) {
    chomp();
    my @line = split( /\s+/, $_ );
    push( @{ $SNPsloc{ $line[0] } }, [ $line[0]."_".$line[1]."-".$line[2]."-".$line[3], $line[1] ] );
}
close SNPLOC;
 }

if($databasetype eq "VCF")
{
open( SNPLOC, $snpDfile );
while (<SNPLOC>) {
    chomp();
    my @line = split( /\t/, $_ );
    push( @{ $SNPsloc{ $line[0] } }, [ $line[0]."_".$line[1]."-".$line[3]."-".$line[4], $line[1],$line[2] ] );
}
close SNPLOC;
 
}




# Compare the Two SNPs

#PLEASE REMMBER To MATCH CHROSMOME NAMES in BOTH SNPS and GENE FILE;
my %hits;
foreach my $ch ( keys(%SNPsloc) ) {
    
    my $CHR = $ch; 
    #if this chr in Results  
    if($insloc{$CHR}){
    
    my @garray = @{$insloc{$CHR}};
    #Sorting genes by start pos
    my @gsorted = sort { $a->[0] <=> $b->[0] } @garray;
     
    #SNPS array

    my @SNPS = @{ $SNPsloc{$ch} };
    #SEARCH IN GENES
    #LOOP Through SNPS
    foreach my $SNP (@SNPS) {
        my $snpstart = $SNP->[1];
        my $snpvcfname=$SNP->[2]; 
        foreach my $GENE (@gsorted) {
            my $gstart = $GENE->[0];
            my $gend   = $GENE->[1];
            my $stD    = $gstart - $snpstart;
            my $stDc = $stD;
            $stDc =~ s/-//;
            my $etD = $gend - $snpstart;
            my $etDc = $etD;
            $etDc =~ s/-//;
                     
            my $genelength = $gend - $gstart;
             #print "$gend - $gstart\t$genelength\n";
             #print "$stDc<$genelength&&$snpstart>=$gend\n";
            if($snpstart<=$gend)
            {
            #print "E\t".$etDc."\t$gend - $snpstart\t$genelength\n";
            #print "S\t".$stDc."\t$gstart - $snpstart\t$genelength\n";  
            }
            if (   $etDc <= $snpDistance
                || $stDc <= $snpDistance 
                || ($stDc<$genelength&&$snpstart<=$gend&&$snpstart>=$gstart)
                 )
            {
                $GENE->[2] =~ s/\s+/\_/g;
                $GENE->[2] =~ s/product\=//g;
                my $genename = $GENE->[2];
                push(
                    @{ $hits{"$genename"}{"locs"} },
                    [ $CHR, $gstart, $gend ]
                );
                $hits{"$genename"}{"hits"}{ $SNP->[0] } = [ $snpstart, $CHR,$snpvcfname ];
            }
            if ( $snpstart < $gend && $stDc >= $snpDistance ) { last; }
        }
    }

}
#The next chr


}


###########PRINT REPORT
open( OFILE, ">>" . $outfile);
open( OVFILE, ">>" . $outfile.".vcf");
open( ORFILE, ">>" . $outfile.".report.txt" );
foreach my $gene ( keys(%hits) ) {
    print ORFILE "#GENE NAME :\t" . $gene . "\n";
    print ORFILE "\t\t#Chromosomal Positions :\n";
    my %seen;
    foreach my $pos ( @{ $hits{$gene}{"locs"} } ) {
            
        my $line="\t\t\t"
          . "CHR:\t"
          . $pos->[0] . "\t"
          . "GENE START:\t"
          . $pos->[1]
          . "\tGENE END:\t"
          . $pos->[2] . "\n"; 
         if(!$seen{$line}){print ORFILE $line;$seen{$line}++; }
    }
    print ORFILE "\t\t" . "##SNPS Located Nearby" . "\n";
    foreach my $snp ( keys( $hits{"$gene"}{"hits"} ) ) {
        
        my $snpname=$snp; 
        #if SNPs has a name 
        if($hits{"$gene"}{"hits"}{$snp}[2] ne ""){$snpname=$hits{"$gene"}{"hits"}{$snp}[2]} 

        print OFILE $snp . "\t"
          . $hits{"$gene"}{"hits"}{$snp}[1] . "\t"
          . $hits{"$gene"}{"hits"}{$snp}[0] . "\t"
          .$snpname."\|".$gene . "\n";
        #CHROM 		POS     ID      REF     ALT    QUAL     FILTER  INFO
        if($snp=~m/\S+\_\d+\-(\w)\-(\w)/g)
        { 
                print OVFILE  $hits{"$gene"}{"hits"}{$snp}[1]."\t"
                      . $hits{"$gene"}{"hits"}{$snp}[0] . "\t"
              	      . $snpname . "\t"
                      . $1."\t"
                      . $2."\t"
                      . "."."\t"
		      . "."."\t"
		      . "."."\n";
	}	        	  
        print ORFILE "\t\t\t"
          . $snpname
          . "\tCHR:"
          . $hits{"$gene"}{"hits"}{$snp}[1]
          . "\tPOS:"
          . $hits{"$gene"}{"hits"}{$snp}[0] . "\n";
    }
}

close OFILE;
close ORFILE;
close OVFILE;
}

#perl Create-Kasp.pl GENOMEFASTA SNPDATABASE  TARGETSNP

#PARAM
#Before SNP
sub create_kasp
{
my ($genomef,$snpDfile,$snpselect,$outfile)=@_;  
my $primerRange=100;


########################
my %snpv;
$snpv{"AC"}="M";
$snpv{"CA"}="M";
$snpv{"AG"}="R";
$snpv{"GA"}="R";
$snpv{"AT"}="W";
$snpv{"TA"}="W";
$snpv{"CG"}="S";
$snpv{"GC"}="S";
$snpv{"TC"}="Y";
$snpv{"CT"}="Y";
$snpv{"GT"}="K";
$snpv{"TG"}="K";
my %seq;
 open(FILE,$genomef);
 my $head;
  while(<FILE>)
  {

  chomp();
  if(/>(\S+)/){$seq{$head}=~s/\s+//g;$head=$1;}
  else{$seq{$head}.=$_;}
 
  }
 close FILE;

my %Msnp;

open(MSFILE,$snpDfile);

my $head;
while(<MSFILE>)
{
 
chomp();

my @line=split(/\,/,$_);
$Msnp{$line[0]}{$line[1]}=$snpv{$line[3].$line[2]};

}
close MSFILE;


my %Tsnp;
open(TSFILE,$snpselect);
my $head;
while(<TSFILE>)
{
chomp();
my @line=split(/\s+/,$_);
my $s=$line[0];
my($A,$V);
if($s=~m/\w+\-(\w+|\-)\-(\w|\-)/g){$A=$1;$V=$2;}
$Tsnp{$line[1]}{$line[2]}{"snpname"}=$s;
$Tsnp{$line[1]}{$line[2]}{"S"}="[$A/$V]";
$Tsnp{$line[1]}{$line[2]}{"gene"}=$line[3];
#print $Msnp{$line[1]}{$line[2]}{"S"}."\n";
}
close TSFILE;


############## READ SNPs by Chromsomes
open(PFILE,">>".$outfile);
#Change to The $ch in snp select or you can use it for chr by chr
foreach my $ch(keys(%seq))
{
	foreach my $pos(keys(%{$Tsnp{$ch}}))
	{
         my $start=$pos-1-$primerRange;
         # SNP real Pos   $pos-1
         my $end=$pos+$primerRange;
         my $ChrSeq=$seq{$ch};
	 my $string=substr($ChrSeq,$start,($end-$start));
         #print $Tsnp{$ch}{$pos}{"S"}."\n";	
         my @prim=split(//,$string);         
         #loop inside seq
         for my $i(0..length($string))
         {         
               #Replace not targetted SNPs 
              # print $Msnp{$ch}->{$start+$i+1}->{"S"}."\n";  
               if($Msnp{$ch}->{$start+$i+1}->{"S"})
               {
                 $prim[$i]=$Msnp{$ch}->{($start+$i+1)}{"S"}; 
               }

               # Search for OUR SNPs             
               if($Tsnp{$ch}{$start+$i+1}{"S"})
               {
                if($i ==$primerRange)
                {
                #If this is the target SNP
                $prim[$i]=$Tsnp{$ch}{($start+$i+1)}{"S"};
                } 
                else
                {
                 #If this SNP is not targetted
                 my $flaset=$Tsnp{$ch}{($start+$i+1)}{"S"};
                    $flaset=~s/\/|\]|\[//g;
                    $prim[$i]=$snpv{$flaset}; 
                } 
               }
         }
           
          print  PFILE $Tsnp{$ch}{$pos}{"snpname"}."\,".join("",@prim)."\,".$Tsnp{$ch}{$pos}{"gene"}."\n";  
	  
         }
}

close PFILE;
}


sub convert_KASP_to_noDeg
{
my ($file)=@_;
my @olines;
open(FILE,$file);
while(<FILE>)
{
chomp();
my @line=split(/,/,$_);

$line[1] =~tr/M/A/;
$line[1] =~tr/R/G/;
$line[1] =~tr/W/A/;
$line[1] =~tr/S/C/;
$line[1] =~tr/Y/C/;
$line[1] =~tr/K/G/;
$line[1] =~tr/V/C/;
$line[1] =~tr/H/C/;
$line[1] =~tr/D/G/;
$line[1] =~tr/B/G/;
$line[1] =~tr/N/C/;
push(@olines,$line[0].",".$line[1].",".$line[2]."\n");
}
close FILE;
open(OFILE,">".$file);
foreach my $l(@olines)
{
  print OFILE $l
}
close OFILE;

}

################ FILTERING RESULTS




sub FILTER_KASP_OUT {
    my($file)=@_;
    my %primersout;
    my $primn;
    my $snpid;
    
    open( KFILE, $file );
    while (<KFILE>) {
        chomp();
        if (
/###############SNPID\:(\S+)	PrimerGroupNumber\:(\d+)  ###############/
          )
        {
            $primn = $2;
            $snpid = $1;
        }
        if (/(Primer_\w_Sequence)\:\s+(\w+)/) {
            $primersout{$snpid}{$primn}{$1} = $2;
        }
        if (
/(Left_Primers_Position|Common_Primer_Position|Product_Length)\:\s+(\d+)/
          )
        {
            $primersout{$snpid}{$primn}{$1} = $2;
        }
        if (
/(Primer_Variants_CONSIDERED|Primer_Variants_FAILED|PRIMER_END_STABILITY|PENALTY|TM|GC_PERCENT|SELF_ANY_TH|SELF_END_TH|HAIRPIN_TH|END_STABILITY)\s+(\d+\.\d+)\s+(\d+\.\d+)\s+(\d+\.\d+)/
          )
        {
            $primersout{$snpid}{$primn}{$1}{"A"} = $2;
            $primersout{$snpid}{$primn}{$1}{"B"} = $3;
            $primersout{$snpid}{$primn}{$1}{"C"} = $4;
        }

    }
    close KFILE;

    #take only degenrates
    #FILTER PRIMERS
    my %nofailedTM;
    foreach my $snp ( keys(%primersout) ) {
        foreach my $p ( keys( %{ $primersout{$snp} } ) ) {
            my $TMA = $primersout{$snp}{$p}{"TM"}{"A"};
            my $TMB = $primersout{$snp}{$p}{"TM"}{"B"};
            my $TMC = $primersout{$snp}{$p}{"TM"}{"C"};
            if ( $TMA ne "0.00" && $TMB ne "0.00" && $TMC ne "0.00" ) {
                $nofailedTM{$snp}{$p} = $primersout{$snp}{$p};
            }
        }
    }

    my %nondegenprimers;
    my @lineshere;
    foreach my $snp ( keys(%nofailedTM) ) {
        my @primerg = keys( %{ $primersout{$snp} } );
        push (@lineshere,"%%%%%%%%%%%%%%%%%%%%% SNPID: $snp Number_of_Primers_Returned "
          . ( $#primerg + 1 )
          . " %%%%%%%%%%%%%%%%\n");

        for my $p ( 0 .. $#primerg ) {
            push (@lineshere,"###############$snp	Primer_Number:"
              . ( $p + 1 )
              . "  ###############\n");
            push (@lineshere,
"--------------General Primers Informations-----------------------------------\n");

            my $AV = $primersout{$snp}{$p}{"Primer_Variants_CONSIDERED"}{"A"};
            my $BV = $primersout{$snp}{$p}{"Primer_Variants_CONSIDERED"}{"B"};
            my $CV = $primersout{$snp}{$p}{"Primer_Variants_CONSIDERED"}{"C"};

            my $ATM = $primersout{$snp}{$p}{"TM"}{"A"};
            my $BTM = $primersout{$snp}{$p}{"TM"}{"B"};
            my $CTM = $primersout{$snp}{$p}{"TM"}{"C"};

            if (   $AV >= 1
                && $BV >= 1
                && $CV >= 1
                && $ATM > 0
                && $CTM > 0
                && $BTM > 0 )
            {

                push (@lineshere,"Primer_A_Sequence:\t"
                  . $primersout{$snp}{$p}{"Primer_A_Sequence"} . "\n");
                push (@lineshere,"Primer_B_Sequence:\t"
                  . $primersout{$snp}{$p}{"Primer_B_Sequence"} . "\n");
                push (@lineshere,"Primer_C_Sequence:\t"
                  . $primersout{$snp}{$p}{"Primer_C_Sequence"} . "\n");
                push (@lineshere,"Left_Primers_Position:\t"
                  . $primersout{$snp}{$p}{"Left_Primers_Position"} . "\n");
                push (@lineshere,"Common_Primer_Position:\t"
                  . $primersout{$snp}{$p}{"Common_Primer_Position"} . "\n");
                push (@lineshere,"Product_Length:\t"
                  . $primersout{$snp}{$p}{"Product_Length"} . "\n");
                push (@lineshere,
"--------------Specific Primers Informations-----------------------------------\n");
                push (@lineshere,"INFO                    A	B	C\n");
                my @items = (
                    "Primer_Variants_CONSIDERED", "Primer_Variants_FAILED",
                    "PRIMER_END_STABILITY",       "PENALTY",
                    "TM",                         "GC_PERCENT",
                    "SELF_ANY_TH",                "SELF_END_TH",
                    "HAIRPIN_TH",                 "END_STABILITY"
                );

                for my $item (@items) {
                 push (@lineshere,  print_for_three( $item, $primersout{$snp}{$p} ));
                }

            }
        }
    }
   
   open(KOFILE,">".$file);
   
   print KOFILE join("",@lineshere);
   close KOFILE; 


}

sub print_for_three {
    my ( $item, $hash ) = @_;
    my $A = $hash->{$item}{"A"};
    my $B = $hash->{$item}{"B"};
    my $C = $hash->{$item}{"C"};
    return $item. "\t" . $A . "\t" . $B . "\t" . $C . "\n";
}




return 1;
