use strict;
use Exporter qw/import/;
use primer3 qw(get_primers  read_spoon_out create_p3_pram  create_pcheck run_primer3  read_p3check_out  print_pchick_result);

#read Spoon KASP OUT
my %snps=read_spoon_out("/home/samman/Desktop/Spoon-19-8-2018-Linux-And-Source-Code/test/KASP-primers.csv");
#Create_Params
        my %params;
        $params{"PRIMER_NUM_RETURN"}                    = 5;
        $params{"SEQUENCE_FORCE_LEFT_END"}              = 100;
        $params{"PRIMER_MIN_SIZE"}                      = 18;
        $params{"PRIMER_OPT_SIZE"}                      = 20;
        $params{"PRIMER_MAX_SIZE"}                      = 36;
        $params{"PRIMER_MIN_TM"}                        = 40;
        $params{"PRIMER_OPT_TM"}                        = 55;
        $params{"PRIMER_MAX_TM"}                        = 65;
        $params{"PRIMER_PAIR_MAX_DIFF_TM"}              = 5;
        $params{"PRIMER_MIN_GC"}                        = 20;
        $params{"PRIMER_OPT_GC_PERCENT"}                = 50;
        $params{"PRIMER_MAX_GC"}                        = 85;     
        $params{"PRIMER_MAX_POLY_X"}                    = 4;
        $params{"PRIMER_MAX_NS_ACCEPTED"}               = 10;
        $params{"PRIMER_PRODUCT_SIZE_RANGE"}="50-250";  
        $params{"PRIMER_LIBERAL_BASE"}                  = 1;
        $params{"PRIMER_INTERNAL_MAX_NS_ACCEPTED"}      = 10;
        $params{"PRIMER_LIB_AMBIGUITY_CODES_CONSENSUS"} = 1;        
        $params{"PRIMER_EXPLAIN_FLAG"}=1; 

#Run primer3
create_p3_pram(\%snps,\%params,$config{"OUTDIR"}.$config{PLATDIR}."p3params");
get_primers("p3params","P3-out.txt");
run_primer3("PCHECK.txt","OUT-PCHECK.txt");
my %checkinfo = read_p3check_out("OUT-PCHECK.txt");
print_pchick_result(\%checkinfo,"test/RESULTS");
