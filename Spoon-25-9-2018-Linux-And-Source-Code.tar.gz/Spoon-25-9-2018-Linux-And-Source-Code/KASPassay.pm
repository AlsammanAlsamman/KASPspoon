package KASPassay;

sub select_snps_nearby
{
my ($Rfile,$snpDfile,$databasetype,$snpDistance,$outfile)=@_;

my %insloc;
open( GLOC, $Rfile );
while (<GLOC>) {
    chomp();
    my @line = split( /\,/, $_ );
    push( @{ $insloc{ $line[6] } }, [ $line[7], $line[8], $line[0]."\|".$line[3]."\|".$line[9] ] );
    
}
close GLOC;

my %SNPsloc;

# Read SNP database 
 if($databasetype eq "LIST")
 {

open( SNPLOC, $snpDfile );
while (<SNPLOC>) {
    chomp();
    my @line = split( /\s+/, $_ );
    push( @{ $SNPsloc{ $line[0] } }, [ $line[0]."_".$line[1]."-".$line[2]."-".$line[3], $line[1] ] );
}
close SNPLOC;
 }

if($databasetype eq "VCF")
{
open( SNPLOC, $snpDfile );
while (<SNPLOC>) {
    chomp();
    my @line = split( /\t/, $_ );
    push( @{ $SNPsloc{ $line[0] } }, [ $line[0]."_".$line[1]."-".$line[3]."-".$line[4], $line[1],$line[2] ] );
}
close SNPLOC;
 
}




# Compare the Two SNPs

#PLEASE REMMBER To MATCH CHROSMOME NAMES in BOTH SNPS and GENE FILE;
my %hits;
foreach my $ch ( keys(%SNPsloc) ) {
    
    my $CHR = $ch; 
    #if this chr in Results  
    if($insloc{$CHR}){
    
    my @garray = @{$insloc{$CHR}};
    #Sorting genes by start pos
    my @gsorted = sort { $a->[0] <=> $b->[0] } @garray;
     
    #SNPS array

    my @SNPS = @{ $SNPsloc{$ch} };
    #SEARCH IN GENES
    #LOOP Through SNPS
    foreach my $SNP (@SNPS) {
        my $snpstart = $SNP->[1];
        my $snpvcfname=$SNP->[2]; 
        foreach my $GENE (@gsorted) {
            my $gstart = $GENE->[0];
            my $gend   = $GENE->[1];
            my $stD    = $gstart - $snpstart;
            my $stDc = $stD;
            $stDc =~ s/-//;
            my $etD = $gend - $snpstart;
            my $etDc = $etD;
            $etDc =~ s/-//;
                     
            my $genelength = $gend - $gstart;
             #print "$gend - $gstart\t$genelength\n";
             #print "$stDc<$genelength&&$snpstart>=$gend\n";
            if($snpstart<=$gend)
            {
            #print "E\t".$etDc."\t$gend - $snpstart\t$genelength\n";
            #print "S\t".$stDc."\t$gstart - $snpstart\t$genelength\n";  
            }
            if (   $etDc <= $snpDistance
                || $stDc <= $snpDistance 
                || ($stDc<$genelength&&$snpstart<=$gend&&$snpstart>=$gstart)
                 )
            {
                $GENE->[2] =~ s/\s+/\_/g;
                $GENE->[2] =~ s/product\=//g;
                my $genename = $GENE->[2];
                push(
                    @{ $hits{"$genename"}{"locs"} },
                    [ $CHR, $gstart, $gend ]
                );
                $hits{"$genename"}{"hits"}{ $SNP->[0] } = [ $snpstart, $CHR,$snpvcfname ];
            }
            if ( $snpstart < $gend && $stDc >= $snpDistance ) { last; }
        }
    }

}
#The next chr


}


###########PRINT REPORT
open( OFILE, ">>" . $outfile);
open( OVFILE, ">>" . $outfile.".vcf");
open( ORFILE, ">>" . $outfile.".report.txt" );
foreach my $gene ( keys(%hits) ) {
    print ORFILE "#GENE NAME :\t" . $gene . "\n";
    print ORFILE "\t\t#Chromosomal Positions :\n";
    my %seen;
    foreach my $pos ( @{ $hits{$gene}{"locs"} } ) {
            
        my $line="\t\t\t"
          . "CHR:\t"
          . $pos->[0] . "\t"
          . "GENE START:\t"
          . $pos->[1]
          . "\tGENE END:\t"
          . $pos->[2] . "\n"; 
         if(!$seen{$line}){print ORFILE $line;$seen{$line}++; }
    }
    print ORFILE "\t\t" . "##SNPS Located Nearby" . "\n";
    foreach my $snp ( keys( $hits{"$gene"}{"hits"} ) ) {
        
        my $snpname=$snp; 
        #if SNPs has a name 
        if($hits{"$gene"}{"hits"}{$snp}[2] ne ""){$snpname=$hits{"$gene"}{"hits"}{$snp}[2]} 

        print OFILE $snp . "\t"
          . $hits{"$gene"}{"hits"}{$snp}[1] . "\t"
          . $hits{"$gene"}{"hits"}{$snp}[0] . "\t"
          .$snpname."\|".$gene . "\n";
        #CHROM 		POS     ID      REF     ALT    QUAL     FILTER  INFO
        if($snp=~m/\S+\_\d+\-(\w)\-(\w)/g)
        { 
                print OVFILE  $hits{"$gene"}{"hits"}{$snp}[1]."\t"
                      . $hits{"$gene"}{"hits"}{$snp}[0] . "\t"
              	      . $snpname . "\t"
                      . $1."\t"
                      . $2."\t"
                      . "."."\t"
		      . "."."\t"
		      . "."."\n";
	}	        	  
        print ORFILE "\t\t\t"
          . $snpname
          . "\tCHR:"
          . $hits{"$gene"}{"hits"}{$snp}[1]
          . "\tPOS:"
          . $hits{"$gene"}{"hits"}{$snp}[0] . "\n";
    }
}

close OFILE;
close ORFILE;
close OVFILE;
}

#perl Create-Kasp.pl GENOMEFASTA SNPDATABASE  TARGETSNP

#PARAM
#Before SNP
sub create_kasp
{
my ($genomef,$snpDfile,$snpselect,$outfile)=@_;  
my $primerRange=100;


########################
my %snpv;
$snpv{"AC"}="M";
$snpv{"CA"}="M";
$snpv{"AG"}="R";
$snpv{"GA"}="R";
$snpv{"AT"}="W";
$snpv{"TA"}="W";
$snpv{"CG"}="S";
$snpv{"GC"}="S";
$snpv{"TC"}="Y";
$snpv{"CT"}="Y";
$snpv{"GT"}="K";
$snpv{"TG"}="K";
my %seq;
 open(FILE,$genomef);
 my $head;
  while(<FILE>)
  {

  chomp();
  if(/>(\S+)/){$seq{$head}=~s/\s+//g;$head=$1;}
  else{$seq{$head}.=$_;}
 
  }
 close FILE;

my %Msnp;

open(MSFILE,$snpDfile);

my $head;
while(<MSFILE>)
{
 
chomp();

my @line=split(/\,/,$_);
$Msnp{$line[0]}{$line[1]}=$snpv{$line[3].$line[2]};

}
close MSFILE;


my %Tsnp;
open(TSFILE,$snpselect);
my $head;
while(<TSFILE>)
{
chomp();
my @line=split(/\s+/,$_);
my $s=$line[0];
my($A,$V);
if($s=~m/\w+\-(\w+|\-)\-(\w|\-)/g){$A=$1;$V=$2;}
$Tsnp{$line[1]}{$line[2]}{"snpname"}=$s;
$Tsnp{$line[1]}{$line[2]}{"S"}="[$A/$V]";
$Tsnp{$line[1]}{$line[2]}{"gene"}=$line[3];
#print $Msnp{$line[1]}{$line[2]}{"S"}."\n";
}
close TSFILE;


############## READ SNPs by Chromsomes
open(PFILE,">>".$outfile);
#Change to The $ch in snp select or you can use it for chr by chr
foreach my $ch(keys(%seq))
{
	foreach my $pos(keys(%{$Tsnp{$ch}}))
	{
         my $start=$pos-1-$primerRange;
         # SNP real Pos   $pos-1
         my $end=$pos+$primerRange;
         my $ChrSeq=$seq{$ch};
	 my $string=substr($ChrSeq,$start,($end-$start));
         #print $Tsnp{$ch}{$pos}{"S"}."\n";	
         my @prim=split(//,$string);         
         #loop inside seq
         for my $i(0..length($string))
         {         
               #Replace not targetted SNPs 
              # print $Msnp{$ch}->{$start+$i+1}->{"S"}."\n";  
               if($Msnp{$ch}->{$start+$i+1}->{"S"})
               {
                 $prim[$i]=$Msnp{$ch}->{($start+$i+1)}{"S"}; 
               }

               # Search for OUR SNPs             
               if($Tsnp{$ch}{$start+$i+1}{"S"})
               {
                if($i ==$primerRange)
                {
                #If this is the target SNP
                $prim[$i]=$Tsnp{$ch}{($start+$i+1)}{"S"};
                } 
                else
                {
                 #If this SNP is not targetted
                 my $flaset=$Tsnp{$ch}{($start+$i+1)}{"S"};
                    $flaset=~s/\/|\]|\[//g;
                    $prim[$i]=$snpv{$flaset}; 
                } 
               }
         }
           
          print  PFILE $Tsnp{$ch}{$pos}{"snpname"}."\,".join("",@prim)."\,".$Tsnp{$ch}{$pos}{"gene"}."\n";  
	  
         }
}

close PFILE;
}

return 1;
