use strict;
use genesaround;
use user_config;
use covstatics;
use extractamps;
use insinvcompare;
use templates;
use MainSpoon;
use circosconf;
use MISA;
use comparemaps;
use report;
use KASPassay;
use Exporter qw/import/;
use primer3 qw(get_primers  read_spoon_out create_p3_pram  create_pcheck run_primer3  read_p3check_out  print_pchick_result);


my %config = user_config::readconfigfile($ARGV[0]);
if($ARGV[0] eq "")
{
 print "Please select Configuration file !\n";
}
my $outputdir = $config{"OUTDIR"}.$config{PLATDIR};

######################	Create Information files from Seq(s) and user configurations
  user_config::createinfofiles(\%config);
######################	Start selected processes
######################	If In silico PCR has been chosen 
   if ( $config{"DOINSILICO"} eq "YES" ) {
       MainSpoon::ins_pcr_c_code(\%config);
    }   
######################	If PCR Statistics has been chosen 
    if ( $config{"PCRSTAT"} eq "YES" ) {       
       covstatics::getstat(\%config);   
    }
######################	If in silico amplicons extraction has been chosen 
    if ( $config{"EXTRACTAMPS"} eq "YES" ) {
        MainSpoon::extractinsamp(\%config);
    }
    
######################	Searching for amplicons adjoin or near genes 
    if ( $config{"GENESAROUND"} eq "YES" ) {

                    my $glocfile=$config{"OUTDIR"}.$config{PLATDIR}."Seq_Genes_Loc.txt"; 
		    #If user providede genbank annotation files
                    if($config{ANNOFILE} eq "GB")
		    {
                     genesaround::createglocfilefromgb(\%config);
		      $config{ANNOFILE} = $glocfile; 
		    }
                    #if user provided list files
		    if($config{ANNOFILE} eq "LIST")
		    {
                     genesaround::createglocfilefromlist(\%config);
                     $config{ANNOFILE} = $glocfile; 
		    }
           genesaround::getgenesaround(\%config);
    }

#################### SEARCH FOR SSR
    if ( $config{"DOSSR"} eq "YES" ) {

        print "Searching for SSR\n";       
        my $infile=$config{"OUTDIR"}.$config{PLATDIR}."In_silico_amplimers_sequence-for-SSR.fasta"; 
        my $insResult=$config{"OUTDIR"}.$config{PLATDIR}."In_silico_PCR_Results.csv";
        MISA::misa($infile,$config{"OUTDIR"}.$config{PLATDIR}."config.info");
        my %MISA=MISA::read_misa($infile.".misa");
        my %insfile=MISA::readinsresult($insResult);
        #WRITE PRIMER MOTIF REPORT
        report::print_primer_motif_report(\%MISA,$config{"OUTDIR"}.$config{PLATDIR}."PRIMER-MOTIF-report.txt"); 
        #WRITE TO FILE
        open(SSRFILE,">".$config{"OUTDIR"}.$config{PLATDIR}."In_silico_PCR_Results_With_SSR.csv");
        foreach my $k(keys(%MISA)){print SSRFILE $insfile{$k}.",".$MISA{$k}."\n"}                
        close SSRFILE;
    }  
##################### KASP ASSAY
if ( $config{CREATEKASP} eq "YES" ) {
     my $snpResult=$config{"OUTDIR"}.$config{PLATDIR}."SNPs-NearBy.txt";
     my $KASP=$config{"OUTDIR"}.$config{PLATDIR}."KASP-Sequences.csv";
     my $snpDB=$config{"SNPFILE"};
     my $snpDistance=$config{"SNPDIST"};
     my $snpdatabasetype=$config{"SNPDATABASETYPE"};
     my $insResult=$config{"OUTDIR"}.$config{PLATDIR}."In_silico_PCR_Results.csv";

     if($config{"KASPFOR"} eq "G")
       {
         $insResult=$config{"OUTDIR"}.$config{PLATDIR}."In_silico_PCR_near_or_adjoin_genes.csv";
       }
     #Search for SNPs nearby
     KASPassay::select_snps_nearby($insResult,$snpDB,$snpdatabasetype,$snpDistance,$snpResult);

     my $dir = $config{FASTADIR};
     my @fafiles = user_config::get_fasta_in_dir($dir,\%config);        
     foreach my $file(@fafiles)
     {
      #Create KASP for each  
      KASPassay::create_kasp($dir.$config{PLATDIR}.$file,$snpDB,$snpResult,$KASP);           
     } 

     ########## KASP PRIMERS CONFIGURATION
         my %snps=read_spoon_out($KASP);     
             my %params;
        $params{"PRIMER_NUM_RETURN"}                    = 3;
        $params{"SEQUENCE_FORCE_LEFT_END"}              = 100;
        $params{"PRIMER_MIN_SIZE"}                      = $config{"PRIMERSIZEMIN"};
        $params{"PRIMER_OPT_SIZE"}                      = $config{"PRIMERSIZEOPT"};
        $params{"PRIMER_MAX_SIZE"}                      = $config{"PRIMERSIZEMAX"};
        $params{"PRIMER_MIN_TM"}                        = $config{"PRIMERTMMIN"};
        $params{"PRIMER_OPT_TM"}                        = $config{"PRIMERTMOPT"};
        $params{"PRIMER_MAX_TM"}                        = $config{"PRIMERTMMAX"};
        $params{"PRIMER_PAIR_MAX_DIFF_TM"}              = $config{"PRIMERTMDIFF"};
        $params{"PRIMER_MIN_GC"}                        = $config{"PRIMERGCMIN"};
        $params{"PRIMER_OPT_GC_PERCENT"}                = $config{"PRIMERGCOPT"};
        $params{"PRIMER_MAX_GC"}                        = $config{"PRIMERGCMAX"};     
        $params{"PRIMER_MAX_POLY_X"}                    = 4;
        $params{"PRIMER_MAX_NS_ACCEPTED"}               = 10;
        $params{"PRIMER_PRODUCT_SIZE_RANGE"}=$config{"PCRPRODUCTMIN"}."-".$config{"PCRPRODUCTMAX"};  
        $params{"PRIMER_LIBERAL_BASE"}                  = 1;
        $params{"PRIMER_INTERNAL_MAX_NS_ACCEPTED"}      = 10;
        $params{"PRIMER_LIB_AMBIGUITY_CODES_CONSENSUS"} = 1;        
        $params{"PRIMER_EXPLAIN_FLAG"}=1; 
        $params{"PRIMER_THERMODYNAMIC_PARAMETERS_PATH"}="bin/primer3_config/";

	create_p3_pram(\%snps,\%params,$config{"OUTDIR"}.$config{PLATDIR}."p3params");
        get_primers($config{"OUTDIR"}.$config{PLATDIR}."p3params",$config{"OUTDIR"}.$config{PLATDIR}."P3-out.txt");
        create_pcheck($config{"OUTDIR"}.$config{PLATDIR}."P3-out.txt",$config{"OUTDIR"}.$config{PLATDIR}."PCHECK.txt"); 
	run_primer3($config{"OUTDIR"}.$config{PLATDIR}."PCHECK.txt",$config{"OUTDIR"}.$config{PLATDIR}."OUT-PCHECK.txt");    
	my %checkinfo = read_p3check_out($config{"OUTDIR"}.$config{PLATDIR}."OUT-PCHECK.txt");
	print_pchick_result(\%checkinfo,$config{"OUTDIR"}.$config{PLATDIR}."RESULTS"."KASP-PRIMERS.txt");
         unlink $config{"OUTDIR"}.$config{PLATDIR}."p3params";
         unlink $config{"OUTDIR"}.$config{PLATDIR}."P3-out.txt";
         unlink $config{"OUTDIR"}.$config{PLATDIR}."PCHECK.txt";
         unlink $config{"OUTDIR"}.$config{PLATDIR}."OUT-PCHECK.txt";   
         
         
} 

#####################	Comparing in silico amplicons to in vitro amplicons	


if ( $config{"PCRALIGN"} eq "YES" ) {
 my @matches=insinvcompare::compare_ins_inv(\%config);
 insinvcompare::print_ins_inv_Amps(\%config,\@matches);
	
               #create circos conf. for ins-inv comparison
               if ( $config{"PCRCIRCOS"} eq "YES" ) {
		  #make direcory 
                  ############ Circos configuration for align in-ins comparison 
		  mkdir $outputdir . "CircosAlign";
		  insinvcompare::create_def_circosalign(\%config,\@matches,$outputdir . "CircosAlign");
		  insinvcompare::print_bands_highlights(\%config,\@matches,$outputdir . "CircosAlign");
		  insinvcompare::print_links_file(\%config,\@matches,$outputdir . "CircosAlign");
		  my $genes=0;
		  if($config{"AlIGNINVITROTO"}=~m/G/g){$genes=1;}
		  templates::createcircoalignconf($outputdir . "CircosAlign".$config{PLATDIR},$genes);
		  if($genes==1)
		  {
		  insinvcompare::print_genes_file_circos_align(\%config,\@matches,$outputdir . "CircosAlign".$config{PLATDIR});
		  } 
               }
          
    }
########################### Create circos conf for in silico Stat.
if ( $config{"PCRCIRCOS"} eq "YES" ) { 
	my %covarea = MainSpoon::readcoveredareas(\%config);
	my @colors=MainSpoon::colors();
	my @parray=sort { lc($a) cmp lc($b) } keys(%covarea);
	my %pn = circosconf::get_prims_n_for_inscircos(\%config);
	my $outputdir = $config{"OUTDIR"}.$config{PLATDIR}."Circos";
	######## These are statistics
	my %anchorprims = covstatics::get_anchor_prims(\%covarea);
	covstatics::print_anchor_pfile(\%anchorprims,\%config);
	############ make dir for circos config
	mkdir $outputdir ;
	circosconf::create_PsetBand_file(\%pn,\%config,$outputdir);
	circosconf::print_link_Pset_hit(\@parray,\%covarea,\%pn,$outputdir,\@colors,\%config);
	my @stats=circosconf::get_cov_stat_for_circos(\%covarea,\@parray);
	#primer coverage statistics
	my %pcstatistics=%{$stats[0]};
	#primer set coverage statistics
	my %pstatistics=%{$stats[1]};
	# Seq areacoverage statistics 
	my %cstatistics=%{$stats[2]};
	# Total area covered by all p. set
	my $tatolcover=$stats[3];
	circosconf::print_circos_statics($outputdir,\%pcstatistics,\%pstatistics,
	\%cstatistics,$tatolcover,\%config,\%pn,\%anchorprims);
	my %areas=covstatics::get_all_covered_areas(\%covarea,\@parray);
	########### get max chrom for circos
	my $maxchrom = covstatics::get_max_Seq_length(\%areas);
	circosconf::print_def_statcircos(\%areas,\%pn,$outputdir,\%config);
	########### Genes file
	circosconf::print_genes_statcircos(\%config,$outputdir,\%areas);
	######### Hit links
	circosconf::print_hitlinks_statcircos(\@colors,\%config,$outputdir,\%pn,\%areas);
	templates::createcircosconf($outputdir.$config{PLATDIR},$maxchrom);

 }

if ( $config{"MAPCOMPARE"} eq "YES" ) { 

print "MAPCOMPARE\n";
my $dir=$config{"MAPFOLDER"};

my @files= comparemaps::get_maps_in_dir($dir);
my $insfile=$config{"OUTDIR"}.$config{PLATDIR}."In_silico_PCR_Results.csv";
my %ins_results=covstatics::readinsresult($insfile);
###### Read maps
my %lginfo;
my %p_map;
my $filepath=$config{"OUTDIR"}.$config{PLATDIR};

my @out_array=comparemaps::read_maps(\@files,$dir.$config{PLATDIR});

%p_map=%{$out_array[0]};
%lginfo=%{$out_array[1]};
##### get Sq infos and key codes
my $keycodefile=$config{"OUTDIR"}.$config{PLATDIR}."keycode.info";
my $seqinfofile=$config{"OUTDIR"}.$config{PLATDIR}."seq.info";
my %seqinfos     = user_config::readseqinfo($seqinfofile);
my %seqkeys      = user_config::readseqkey($keycodefile);
my %covarea = MainSpoon::readcoveredareas(\%config);
my @parray=sort { lc($a) cmp lc($b) } keys(%covarea);
my %areas=covstatics::get_all_covered_areas(\%covarea,\@parray);
my $maxchrom = covstatics::get_max_Seq_length(\%areas);
my %pn=circosconf::get_prims_n_for_inscircos(\%config);
my $OutDir=$config{"OUTDIR"}.$config{PLATDIR}."CircosCompare".$config{PLATDIR};
my @outdir = comparemaps::print_links_compare_file(\%ins_results,\%p_map,$OutDir,\%seqkeys,\%pn);
my %chrs_here=%{$outdir[0]};
my %lgs_here=%{$outdir[1]};
comparemaps::lg_chr_assign_file(\%lgs_here,\%seqkeys,$config{"OUTDIR"}.$config{PLATDIR});

if ( $config{"PCRCIRCOS"} eq "YES" ) { 
#Create map Compare Dir
mkdir $config{"OUTDIR"}.$config{PLATDIR}."CircosCompare";
comparemaps::print_def(\%chrs_here,\%lgs_here,\%seqkeys,\%seqinfos,\%lginfo,$OutDir);
my @lgs=keys(%lgs_here);
templates::Circos_compare_config(\@lgs,$maxchrom,$OutDir);
}

}

######################################### Create finished process report
######################################### Create Report Table
    my $outputdir = $config{"OUTDIR"}.$config{PLATDIR};
    my $insfile     = $outputdir . "In_silico_PCR_Results.csv";
    my $ingfile     = $outputdir . "In_silico_PCR_near_or_adjoin_genes.csv";
    my $insinvfile  = $outputdir . "INS_INV_Amps.txt";
    my $insssr      = $outputdir .  "In_silico_PCR_Results_With_SSR.csv";
    my $covstatfile = $outputdir . "Coverage_statistical_analysis_output_by_base_pair.csv";
    my $allinsbands = 0;
    my $tgenes      = 0;
    my $totalcov    = 0;
    my $totalcovper = 0;
    my $anchc       = 0;
    my @allprimers=MainSpoon::get_primers_names_from_file(\%config);

    ##If these results existed add to report
    my %ft = ();
    stat($insfile);              
    if ( -e _ ) {
         print "Reading in silico FILES\n";                  
        my @out = report::readins($insfile,\%ft,$allinsbands);
        %ft=%{$out[0]};
        $allinsbands=$out[1];
          
    }
    
    stat($insssr);              
    if ( -e _ ) {
        print "Reading SSR FILES\n";                  
        my %ft = report::readSSR($insssr,\%ft);
    }
    
    stat($covstatfile);
    if ( -e _ ) {
        my @cout = report::covstat($covstatfile,\%ft,$totalcov);
        %ft=%{$cout[0]};
        $totalcov=$cout[1];
        my @statout = report::covper( $outputdir . "Coverage_statistical_analysis_output_by_percentage.csv",\%ft,$totalcovper);
        %ft=%{$statout[0]};
        $totalcovper=$statout[1];
        print "Reading in silico coverage FILES\n";
    }

    stat($ingfile);
    if ( -e _ ) {
        %ft = report::reading($ingfile,\%ft);
        my @gout=report::get_agene_count_and_anchror_chr(\%ft);  
        $tgenes=$gout[0]; 
        $anchc=$gout[1];
   
        print "Reading Genic in silico FILES\n";
    }

    stat($insinvfile);
    if ( -e _ ) {
         %ft = report::readinvins($insinvfile,\%ft);
        print "Reading in vitro in silico Comparison  FILES\n";
    }
     
################################# print table
    report::print_report_table(\%ft,$outputdir);
######################################### Create Report Text

    open( RTTXT, ">" . $outputdir . "Report_text.txt" );
    print RTTXT "Total number of primers :" . "\t"
      . ( $#allprimers + 1 )
      . "\tprimer(s)\n";
    print RTTXT "Total number of primers with hits :" . "\t" .
      keys(%ft) . "\tprimer(s)\n";
    print RTTXT "Total number of insilico bands :" . "\t"
      . $allinsbands
      . "\t band(s)\n";
    print RTTXT "Total number of genic insilico bands :" . "\t" . $tgenes
      . "\t gene(s)\n";
    print RTTXT "Genome Coverage :" . "\t"
      . $totalcov
      . "bp\t which about $totalcovper% of the total area\n";
    print RTTXT "Primers exists in one chr (anchor) :" . "\t" . $anchc
      . "\tprimer(s)\n";
    close RTTXT;

############################################## END

